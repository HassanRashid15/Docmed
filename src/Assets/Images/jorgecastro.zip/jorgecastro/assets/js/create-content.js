/**
 * Create Content page: single popup with dynamic fields per content type.
 */
(function ($) {
    'use strict';

    var $popup = $('#jorgecastro-create-content-popup');
    var $titleEl = $('#jorgecastro-create-popup-title');
    var $titleForEl = $('#jorgecastro-create-popup-title-for');
    var $typeInput = $('#jorgecastro-create-content-type');
    var $fieldGroups = $('.jorgecastro-field-group');
    var $form = $('#jorgecastro-create-content-form');
    var $videoTitleDescWrap = $('#jorgecastro-cc-video-title-desc-wrap');
    var $videoPlaceholder = $('#jorgecastro-cc-video-placeholder');
    var $videoEl = $('#jorgecastro-cc-title-desc-video');
    var $videoCategoryWrap = $('#jorgecastro-cc-video-category-wrap');
    var $videoCategoryEl = $('#jorgecastro-cc-category-video');
    var $stepsText = $('#jorgecastro-cc-steps-text');
    var siteName = (typeof window.jorgecastroCreateContent !== 'undefined' && window.jorgecastroCreateContent.site_name) ? window.jorgecastroCreateContent.site_name : '';
    var siteUrl = (typeof window.jorgecastroCreateContent !== 'undefined' && window.jorgecastroCreateContent.site_url) ? window.jorgecastroCreateContent.site_url : '';

    function openPopup(contentType, title) {
        $typeInput.val(contentType || '');

        // Title, steps text and video by content type
        if (contentType === 'title_and_description') {
            $titleEl.text('Write a title & description that shows up on Google');
            $titleForEl.text(' for: ' + (siteName || '')).show();
            if ($stepsText.length) $stepsText.text('Follow the steps below to create your content');
            if ($videoTitleDescWrap.length) $videoTitleDescWrap.removeClass('jorgecastro-hidden');
            if ($videoCategoryWrap.length) $videoCategoryWrap.addClass('jorgecastro-hidden');
            if ($videoPlaceholder.length) $videoPlaceholder.addClass('jorgecastro-hidden');
            if ($videoEl.length && $videoEl[0]) $videoEl[0].load();
            if ($videoCategoryEl.length && $videoCategoryEl[0]) $videoCategoryEl[0].pause();
        } else if (contentType === 'product_category') {
            $titleEl.text('Create SEO-optimized category text for:');
            $titleForEl.text(' ' + (siteName || '')).show();
            if ($stepsText.length) $stepsText.text('Follow the steps below to create text that helps both Google and your customers understand the page.');
            if ($videoCategoryWrap.length) $videoCategoryWrap.removeClass('jorgecastro-hidden');
            if ($videoTitleDescWrap.length) $videoTitleDescWrap.addClass('jorgecastro-hidden');
            if ($videoPlaceholder.length) $videoPlaceholder.addClass('jorgecastro-hidden');
            if ($videoCategoryEl.length && $videoCategoryEl[0]) $videoCategoryEl[0].load();
            if ($videoEl.length && $videoEl[0]) $videoEl[0].pause();
        } else {
            $titleEl.text(title || 'Create Content');
            $titleForEl.hide();
            if ($stepsText.length) $stepsText.text('Follow the steps below to create your content');
            if ($videoTitleDescWrap.length) $videoTitleDescWrap.addClass('jorgecastro-hidden');
            if ($videoCategoryWrap.length) $videoCategoryWrap.addClass('jorgecastro-hidden');
            if ($videoPlaceholder.length) $videoPlaceholder.removeClass('jorgecastro-hidden');
            if ($videoEl.length && $videoEl[0]) $videoEl[0].pause();
            if ($videoCategoryEl.length && $videoCategoryEl[0]) $videoCategoryEl[0].pause();
        }

        // Hide all field groups, then show only the one for this content type
        $fieldGroups.addClass('jorgecastro-hidden');
        if (contentType) {
            $fieldGroups.filter('[data-content-type="' + contentType + '"]').removeClass('jorgecastro-hidden');
        }

        $form[0] && $form[0].reset();
        $typeInput.val(contentType || '');
        searchTermKeywords = [];
        renderSearchTermTags();
        updateSearchTermCounter();
        categoryKeywords = [];
        renderCategoryTags();
        syncCategoryHidden();
        updateCategoryCounter();
        if (contentType === 'product_category' && siteUrl) {
            $('#jorgecastro-cc-target-url').attr('placeholder', siteUrl);
        }

        $popup.removeClass('jorgecastro-hidden').hide().fadeIn(200);
    }

    var searchTermKeywords = [];
    var searchTermMax = 1;

    function addSearchTermKeyword(word) {
        word = (word || '').trim();
        if (!word || searchTermKeywords.length >= searchTermMax) return;
        searchTermKeywords.push(word);
        renderSearchTermTags();
        syncSearchTermHidden();
        updateSearchTermCounter();
    }

    function removeSearchTermKeyword(index) {
        searchTermKeywords.splice(index, 1);
        renderSearchTermTags();
        syncSearchTermHidden();
        updateSearchTermCounter();
    }

    function renderSearchTermTags() {
        var $container = $('#jorgecastro-cc-keywords-tags');
        if (!$container.length) return;
        $container.empty();
        searchTermKeywords.forEach(function (kw, i) {
            var $tag = $('<span class="jorgecastro-cc-keyword-tag"></span>');
            $tag.text(kw);
            var $x = $('<button type="button" class="jorgecastro-cc-tag-remove" aria-label="Remove">×</button>');
            $x.on('click', function () { removeSearchTermKeyword(i); });
            $tag.append($x);
            $container.append($tag);
        });
    }

    function syncSearchTermHidden() {
        var $hidden = $('#jorgecastro-cc-search-term');
        if ($hidden.length) $hidden.val(searchTermKeywords.join(', '));
    }

    function updateSearchTermCounter() {
        var $count = $('#jorgecastro-cc-count');
        if ($count.length) $count.text(searchTermKeywords.length);
    }

    // Product Category: "What is the category about?" (1 phrase, tag style)
    var categoryKeywords = [];
    var categoryMax = 1;

    function addCategoryKeyword(word) {
        word = (word || '').trim();
        if (!word || categoryKeywords.length >= categoryMax) return;
        categoryKeywords.push(word);
        renderCategoryTags();
        syncCategoryHidden();
        updateCategoryCounter();
    }

    function removeCategoryKeyword(index) {
        categoryKeywords.splice(index, 1);
        renderCategoryTags();
        syncCategoryHidden();
        updateCategoryCounter();
    }

    function renderCategoryTags() {
        var $container = $('#jorgecastro-cc-category-tags');
        if (!$container.length) return;
        $container.empty();
        categoryKeywords.forEach(function (kw, i) {
            var $tag = $('<span class="jorgecastro-cc-keyword-tag"></span>');
            $tag.text(kw);
            var $x = $('<button type="button" class="jorgecastro-cc-tag-remove" aria-label="Remove">×</button>');
            $x.on('click', function () { removeCategoryKeyword(i); });
            $tag.append($x);
            $container.append($tag);
        });
    }

    function syncCategoryHidden() {
        var $hidden = $('#jorgecastro-cc-category-about');
        if ($hidden.length) $hidden.val(categoryKeywords.join(', '));
    }

    function updateCategoryCounter() {
        var $count = $('#jorgecastro-cc-category-count');
        if ($count.length) $count.text(categoryKeywords.length);
    }

    function closePopup() {
        $popup.fadeOut(200, function () {
            $(this).addClass('jorgecastro-hidden');
        });
    }

    $(document).on('click', '.jorgecastro-open-create-popup', function (e) {
        e.preventDefault();
        var contentType = $(this).data('content-type');
        var title = $(this).data('title');
        openPopup(contentType, title);
    });

    $(document).on('click', '.jorgecastro-create-popup-close', function (e) {
        e.preventDefault();
        closePopup();
    });

    // Close on overlay click (click outside the box)
    $popup.on('click', function (e) {
        if (e.target === this) {
            closePopup();
        }
    });

    // Close on Escape
    $(document).on('keydown', function (e) {
        if (e.key === 'Escape' && $popup.length && !$popup.hasClass('jorgecastro-hidden')) {
            closePopup();
        }
    });

    $form.on('submit', function (e) {
        e.preventDefault();
        closePopup();
    });

    // Enter or comma: add keyword and clear input (Title & Description)
    $(document).on('keydown', '#jorgecastro-cc-search-term-input', function (e) {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            var val = $(this).val().trim();
            if (val) addSearchTermKeyword(val);
            $(this).val('');
        }
    });

    // Enter or comma: add category phrase (Product Category)
    $(document).on('keydown', '#jorgecastro-cc-category-about-input', function (e) {
        if (e.key === 'Enter' || e.key === ',') {
            e.preventDefault();
            var val = $(this).val().trim();
            if (val) addCategoryKeyword(val);
            $(this).val('');
        }
    });
})(jQuery);
