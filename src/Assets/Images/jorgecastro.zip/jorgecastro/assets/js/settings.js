/**
 * jorgeCastro Admin Settings JavaScript
 * Handles connection/disconnection with jorgeCastro SaaS
 */
jQuery(document).ready(function ($) {
  "use strict";

  // Toast notification
  function showToast(message, type) {
    var toastClass = type === "error" ? "cg-toast-error" : "cg-toast-success";
    var toast = $(
      '<div class="cg-toast ' +
        toastClass +
        ' cg-toast-show">' +
        message +
        "</div>"
    );
    $("body").append(toast);

    setTimeout(function () {
      toast.removeClass("cg-toast-show");
      setTimeout(function () {
        toast.remove();
      }, 300);
    }, 3000);
  }

  // Update Connect button state based on API key input
  function updateConnectButtonState() {
    var apiKey = $("#cg_api_key_input").val().trim();
    var $submitBtn = $("#cg-submit-api-key");

    if (apiKey.length > 0) {
      $submitBtn.prop("disabled", false).removeClass("cg-btn-disabled");
    } else {
      $submitBtn.prop("disabled", true).addClass("cg-btn-disabled");
    }
  }

  // Show API Key Popup
  function showApiKeyPopup() {
    $("#cg-api-key-popup").removeClass("jorgecastro-hidden").fadeIn(300);
    $("#cg_api_key_input").focus();
    $("#cg-api-error").addClass("jorgecastro-hidden");
    $("body").css("overflow", "hidden");
    updateConnectButtonState(); // Disable button initially
  }

  // Hide API Key Popup
  function hideApiKeyPopup() {
    $("#cg-api-key-popup").fadeOut(300, function() {
      $(this).addClass("jorgecastro-hidden");
    });
    $("#cg_api_key_input").val("");
    $("#cg-api-error").addClass("jorgecastro-hidden");
    $("body").css("overflow", "");
  }

  // API Key input change - enable/disable Connect button
  $(document).on("input", "#cg_api_key_input", function () {
    updateConnectButtonState();
    $("#cg-api-error").addClass("jorgecastro-hidden");
  });

  // Cancel button click
  $(document).on("click", "#cg-cancel-api-popup", function (e) {
    e.preventDefault();
    hideApiKeyPopup();
  });

  // Close X button click
  $(document).on("click", "#cg-close-popup-x", function (e) {
    e.preventDefault();
    hideApiKeyPopup();
  });

  // Submit API Key (Enter key)
  $(document).on("keypress", "#cg_api_key_input", function (e) {
    if (e.which === 13 && $("#cg_api_key_input").val().trim() !== "") {
      e.preventDefault();
      $("#cg-submit-api-key").click();
    }
  });

  // Show Manage Connection Popup
  function showManagePopup() {
    $("#cg-manage-connection-popup").removeClass("jorgecastro-hidden").fadeIn(300);
    $("body").css("overflow", "hidden");
  }

  function hideManagePopup() {
    $("#cg-manage-connection-popup").fadeOut(300, function() {
      $(this).addClass("jorgecastro-hidden");
    });
    // Reset key visibility state
    $("#cg_current_api_key").attr("type", "password");
    $("#cg-toggle-key-visibility").html(
      '<span class="dashicons dashicons-visibility"></span> Show Key'
    );
    $("body").css("overflow", "");
  }

  // Connection button click (Main Handler)
  $(document).on("click", "#jorgecastro_connection_button", function (e) {
    e.preventDefault();
    var $btn = $(this);
    var href = $btn.attr("href");

    if (href === "#connect") {
      showApiKeyPopup();
    } else if (href === "#disconnect") {
      // Open new Manage Popup instead of confirm dialog
      showManagePopup();
    }
  });

  // Also handle click on Header Badge to open manage popup
  $(document).on("click", ".jorgecastro-connected-badge-btn", function (e) {
    e.preventDefault();
    showManagePopup();
  });

  // Manage Popup: Close buttons
  $(document).on(
    "click",
    "#cg-close-manage-popup, #cg-close-manage-popup-x",
    function (e) {
      e.preventDefault();
      hideManagePopup();
    }
  );

  // Manage Popup: Show/Hide Key Toggle
  $(document).on("click", "#cg-toggle-key-visibility", function (e) {
    e.preventDefault();
    var input = $("#cg_current_api_key");
    var btn = $(this);

    if (input.attr("type") === "password") {
      input.attr("type", "text");
      btn.html('<span class="dashicons dashicons-hidden"></span> Hide Key');
    } else {
      input.attr("type", "password");
      btn.html('<span class="dashicons dashicons-visibility"></span> Show Key');
    }
  });

  // Manage Popup: Copy Key
  $(document).on("click", "#cg-copy-api-key", function (e) {
    e.preventDefault();
    var input = document.getElementById("cg_current_api_key");
    input.select();
    input.setSelectionRange(0, 99999); /* For mobile devices */

    try {
      navigator.clipboard.writeText(input.value).then(function () {
        showToast("Key copied to clipboard!", "success");
      });
    } catch (err) {
      // Fallback
      document.execCommand("copy");
      showToast("Key copied to clipboard!", "success");
    }
  });

  // Manage Popup: Disconnect Button
  $(document).on("click", "#cg-disconnect-btn", function (e) {
    e.preventDefault();
    if (confirm("Are you sure you want to disconnect from jorgeCastro?")) {
      var $btn = $(this);
      var originalText = $btn.find("strong").text();

      $btn.css("opacity", "0.7").css("pointer-events", "none");
      $btn.find("strong").text("Disconnecting...");

      // Use a dummy button element for the performConnection callback context if needed,
      // or just pass the stack button. simpler to just pass this button.
      performConnection("disconnect", null, $btn, function (success) {
        if (!success) {
          $btn.css("opacity", "1").css("pointer-events", "auto");
          $btn.find("strong").text(originalText);
        }
      });
    }
  });

  // Update Update Key button state based on input
  function updateUpdateKeyButtonState() {
    var newKey = $("#cg_new_api_key_input").val().trim();
    var $updateBtn = $("#cg-confirm-update-key");

    if (newKey.length > 0) {
      $updateBtn.prop("disabled", false).removeClass("cg-btn-disabled");
    } else {
      $updateBtn.prop("disabled", true).addClass("cg-btn-disabled");
    }
  }

  // Manage Popup: Update Key Button (Toggles Inline Form)
  $(document).on("click", "#cg-update-key-btn", function (e) {
    e.preventDefault();
    $(this).slideUp(200); // Hide the main button
    $("#cg-inline-update-form").removeClass("jorgecastro-hidden").slideDown(200); // Show the inline form
    $("#cg_new_api_key_input").focus();
    updateUpdateKeyButtonState(); // Disable button initially
  });

  // Manage Popup: Cancel Update
  $(document).on("click", "#cg-cancel-update-key", function (e) {
    e.preventDefault();
    $("#cg-inline-update-form").slideUp(200, function() {
      $(this).addClass("jorgecastro-hidden");
    }); // Hide form
    $("#cg-update-key-btn").slideDown(200); // Show button back
    $("#cg_new_api_key_input").val(""); // Clear input
    updateUpdateKeyButtonState(); // Disable button when cleared
  });

  // New API Key input change - enable/disable Update Key button
  $(document).on("input", "#cg_new_api_key_input", function () {
    updateUpdateKeyButtonState();
  });

  // Manage Popup: Confirm Inline Update
  $(document).on("click", "#cg-confirm-update-key", function (e) {
    e.preventDefault();
    var newKey = $("#cg_new_api_key_input").val().trim();

    if (newKey === "") {
      showToast("Please enter a valid connection key.", "error"); // Use toast for inline error
      $("#cg_new_api_key_input").focus();
      return;
    }

    var $btn = $(this);
    var originalText = $btn.html();
    $btn
      .prop("disabled", true)
      .html(
        '<span class="dashicons dashicons-update spin"></span> Updating...'
      );

    // Reuse performConnection but context is important
    performConnection(
      "connect",
      newKey,
      $("#jorgecastro_connection_button"), // dummy for icon spinner outside, mostly irrelevant for this flow
      function (success, errorMsg) {
        if (success) {
          // On success, page reloads automatically via performConnection
        } else {
          $btn.prop("disabled", false).html(originalText);
          // Show error as toast for update key flow
          if (errorMsg) {
            showToast(errorMsg, "error");
          }
        }
      },
      true // isUpdateKeyFlow - show errors as toast
    );
  });

  // Submit API Key button click (Legacy/First Connect)
  $(document).on("click", "#cg-submit-api-key", function (e) {
    e.preventDefault();

    var apiKey = $("#cg_api_key_input").val().trim();

    if (apiKey === "") {
      $("#cg-api-error").text("Please enter your API key.").removeClass("jorgecastro-hidden").slideDown(200);
      $("#cg_api_key_input").focus();
      return;
    }

    var $submitBtn = $(this);
    var originalText = $submitBtn.html();
    $submitBtn
      .prop("disabled", true)
      .html(
        '<span class="dashicons dashicons-update spin"></span> Connecting...'
      );
    $("#cg-api-error").hide();

    performConnection(
      "connect",
      apiKey,
      $("#jorgecastro_connection_button"),
      function (success, errorMsg) {
        if (success) {
          hideApiKeyPopup();
        } else {
          $submitBtn.prop("disabled", false).html(originalText);
          // Error is already shown in #cg-api-error by performConnection
        }
      },
      false // Not update key flow - show error in popup
    );
  });

  // Perform connection/disconnection
  // isUpdateKeyFlow: if true, show errors as toast instead of in the first popup
  function performConnection(action, apiKey, $btn, callback, isUpdateKeyFlow) {
    var data = {
      action: "jorgecastro_app_connection",
      aj: action,
      nonce: jorgecastro_ajax.nonce,
    };

    if (action === "connect" && apiKey) {
      data.api_key = apiKey;
    }

    $.ajax({
      url: jorgecastro_ajax.ajaxurl || ajaxurl,
      type: "POST",
      data: data,
      beforeSend: function () {
        // Only add loading class if it's the main connection button,
        // strictly purely cosmetic for the old button style.
        if (action === "disconnect" && $btn.hasClass("ml-btn-pill")) {
          $btn.addClass("loading");
        }
      },
      success: function (res) {
        if (res.success) {
          showToast(
            action === "connect"
              ? "Connected successfully!"
              : "Disconnected successfully!",
            "success"
          );

          // Reload page after success
          setTimeout(function () {
            location.reload();
          }, 1000);

          if (callback) callback(true);
        } else {
          var errorMsg = res.error || "Connection failed. Please try again.";

          if (action === "connect" && !isUpdateKeyFlow) {
            // Show in first popup's error area
            $("#cg-api-error").text(errorMsg).removeClass("jorgecastro-hidden").slideDown(200);
          } else {
            // Show as toast for update key flow or disconnect
            showToast(errorMsg, "error");
          }

          if (callback) callback(false, errorMsg);
        }
      },
      error: function (xhr, status, error) {
        var errorMsg = "An error occurred. Please try again.";
        
        // Try to get more specific error message
        if (xhr.responseJSON && xhr.responseJSON.error) {
          errorMsg = xhr.responseJSON.error;
        } else if (xhr.responseText) {
          try {
            var response = JSON.parse(xhr.responseText);
            if (response.error) {
              errorMsg = response.error;
            }
          } catch (e) {
            // Use default error message
          }
        }
        
        if (action === "connect" && !isUpdateKeyFlow) {
          // Show in first popup's error area
          $("#cg-api-error").text(errorMsg).removeClass("jorgecastro-hidden").slideDown(200);
        } else {
          // Show as toast for update key flow or disconnect
          showToast(errorMsg, "error");
        }
        
        if (callback) callback(false, errorMsg);
      },
      complete: function () {
        $btn.removeClass("loading");
      },
    });
  }
});
