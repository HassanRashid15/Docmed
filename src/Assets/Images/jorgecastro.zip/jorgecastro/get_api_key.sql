SELECT option_value FROM wp_options WHERE option_name = 'jorgecastro_settings';
