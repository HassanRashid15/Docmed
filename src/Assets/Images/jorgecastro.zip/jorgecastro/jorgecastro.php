<?php

/**
 * @link              https://your-saas-app.com/
 * @since             1.0.0
 * @package           jorgeCastro
 *
 * @wordpress-plugin
 * Plugin Name:       JorgeCastro
 * Description:       Modern SEO with AI – create SEO texts that rank and increase your visibility. Get more customers, even in AI-powered search results, without needing to know SEO.
 * Version:           1.0.0
 * Author:            JorgeCastro
 * Author URI:        https://jorgecastro.ai/
 * License:           GPL-2.0 or later
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       jorgecastro
 * Domain Path:       /languages
 * Requires at least: 5.0
 * Requires PHP:      7.2
 */

// If this file is called directly, abort.
defined('WPINC') || exit;

// Include utility functions
include_once __DIR__ . '/utils.php';

if (!class_exists('JorgeCastro')) {
    class JorgeCastro
    {
        public $plugin_slug;
        public $plugin_path;
        public $plugin_url;
        public $version = '1.0.0';
        
        /**
         * @var \Marketlytics\API\Client|null
         */
        private $api_client = null;
        
        private $settings = null;
        private $log_file = null;

        // Settings constants
        const SETTINGS_KEY = 'jorgecastro_settings';
        const PLUGIN_FILE = 'jorgecastro.php';
        const REST_VERSION = 1;

        public function __construct()
        {
            // Set exception handler for error logging
            set_exception_handler(function ($e) {
                $record = [
                    'type' => 'exceptionHandler',
                    'message' => $e->getMessage(),
                    'code' => $e->getCode(),
                    'backtrace' => []
                ];
                foreach ($e->getTrace() as $item) {
                    if (isset($item['file'])) {
                        $file = $item['file'];
                    } else {
                        $file = 'unknown';
                    }
                    if (isset($item['line'])) {
                        $line = $item['line'];
                    } else {
                        $line = -1;
                    }
                    $record['backtrace'][] = [
                        $file,
                        $line
                    ];
                }
                $this->writeLog($record);
            });

            $this->plugin_slug = plugin_basename(__DIR__);
            $this->plugin_path = plugin_dir_path(__FILE__);
            $this->plugin_url = plugin_dir_url(__FILE__);
            
            // Initialize log file path in uploads directory
            $this->jorgecastro_init_log_file();

            // Admin hooks
            if (is_admin()) {
                $this->adminPages();
                add_filter('plugin_action_links_' . plugin_basename($this->plugin_path . self::PLUGIN_FILE), [$this, 'adminSettingsLink']);

                // Add filter for posts list page to show only SAAS-generated posts
                add_action('restrict_manage_posts', [$this, 'jorgecastro_add_posts_filter']);
                add_action('pre_get_posts', [$this, 'jorgecastro_filter_posts_by_saas']);

                register_deactivation_hook(__FILE__, [$this, 'deactivate']);
            }

            // AJAX hooks for webhooks - only for logged-in administrators
            // External services should use REST API endpoints which have proper API key authentication
            if (wp_doing_ajax()) {
                add_action('wp_ajax_jorgecastro-notify', [$this, 'ajaxWebhook']);
                // Note: nopriv removed for security - external services must use REST API
            }

            // REST API hooks for receiving data from SaaS app
            add_action('rest_api_init', [$this, 'initRest']);
        }

        public function deactivate()
        {
            if ($this->isConnected()) {
                $this->disconnect();
            }
        }

        public function adminSettingsLink($links)
        {
            array_unshift(
                $links,
                '<a href="' . esc_url($this->getPageUrl('jorgecastro-setting')) . '">Settings</a>'
            );
            return $links;
        }

        public function getPageUrl($page)
        {
            $args = ['page' => $page];
            return add_query_arg($args, admin_url('admin.php'));
        }

        public function getSettings()
        {
            if (is_null($this->settings)) {
                $this->settings = get_option(self::SETTINGS_KEY, []);
                if (!is_array($this->settings)) {
                    $this->settings = [];
                }
            }
            return $this->settings;
        }

        public function setSettings($data)
        {
            $modified = false;
            foreach ($data as $k => $v) {
                if (is_null($v)) {
                    if (isset($this->settings[$k])) {
                        unset($this->settings[$k]);
                        $modified = true;
                    }
                } elseif (!isset($this->settings[$k]) || ($this->settings[$k] !== $v)) {
                    $this->settings[$k] = $v;
                    $modified = true;
                }
            }

            if ($modified) {
                if (count($this->settings) > 0) {
                    update_option(self::SETTINGS_KEY, $this->settings);
                } else {
                    delete_option(self::SETTINGS_KEY);
                }
            }
        }

        public function deleteSettings()
        {
            $this->settings = [];
            delete_option(self::SETTINGS_KEY);
        }

        /**
         * @return bool
         */
        public function isConnected()
        {
            $settings = $this->getSettings();
            return !empty($settings['api_key']);
        }

        public function connect($params)
        {
            return $this->getAPIClient()->connect($params);
        }

        public function disconnect()
        {
            return $this->getAPIClient()->disconnect();
        }

        /**
         * Initialize REST API endpoints for receiving data from SaaS app
         */
        public function initRest()
        {
            register_rest_route($this->getRestNamespace(), '/webhook', [
                'methods' => 'POST',
                'callback' => [$this, 'restWebhook'],
                'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
            ]);
            register_rest_route($this->getRestNamespace(), '/log', [
                'methods' => 'POST',
                'callback' => [$this, 'restLog'],
                'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
            ]);
            register_rest_route($this->getRestNamespace(), '/bulk-posts', [
                'methods' => 'POST',
                'callback' => [$this, 'restBulkPosts'],
                'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
            ]);
            register_rest_route($this->getRestNamespace(), '/woocommerce-products', [
                'methods' => 'GET',
                'callback' => [$this, 'restWooCommerceProducts'],
                'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
            ]);
            register_rest_route($this->getRestNamespace(), '/woocommerce-products/update', [
                'methods' => 'POST',
                'callback' => [$this, 'restUpdateWooCommerceProducts'],
                'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
            ]);
            register_rest_route($this->getRestNamespace(), '/woocommerce-categories', [
                [
                    'methods' => 'GET',
                    'callback' => [$this, 'restGetWooCommerceCategories'],
                    'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
                ],
                [
                    'methods' => 'POST',
                    'callback' => [$this, 'restCreateWooCommerceCategory'],
                    'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
                ]
            ]);
            register_rest_route($this->getRestNamespace(), '/woocommerce-categories/(?P<id>\d+)', [
                [
                    'methods' => 'PUT',
                    'callback' => [$this, 'restUpdateWooCommerceCategory'],
                    'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
                ],
                [
                    'methods' => 'DELETE',
                    'callback' => [$this, 'restDeleteWooCommerceCategory'],
                    'permission_callback' => [$this, 'jorgecastro_rest_permission_callback']
                ]
            ]);
        }

        /**
         * REST API permission callback - validates API key and/or WordPress user capabilities
         * 
         * This endpoint supports two authentication methods:
         * 1. API Key authentication (X-API-Key header) - for external SaaS application calls
         * 2. WordPress user authentication - for logged-in administrators
         * 
         * At least one authentication method must be satisfied.
         * 
         * @param WP_REST_Request $request
         * @return bool|WP_Error True if authorized, WP_Error if not
         */
        public function jorgecastro_rest_permission_callback($request)
        {
            $settings = $this->getSettings();
            $header_api_key = $request->get_header('X-API-Key');
            
            // Method 1: API Key authentication (for external service calls)
            // The API key acts as service-level authentication for the external SaaS application
            $api_key_valid = !empty($settings['api_key']) 
                && !empty($header_api_key) 
                && hash_equals($settings['api_key'], $header_api_key);
            
            // Method 2: WordPress user capability check (for internal/admin calls)
            // Allows logged-in administrators to also access these endpoints
            $user_can_manage = current_user_can('manage_options');
            
            // At least one authentication method must be satisfied
            if ($api_key_valid || $user_can_manage) {
                return true;
            }
            
            // Neither authentication method succeeded
            return new WP_Error(
                'rest_forbidden',
                __('You do not have permission to access this resource. Provide a valid API key or log in as an administrator.', 'jorgecastro'),
                array('status' => 403)
            );
        }

        /**
         * Get REST API namespace
         * 
         * @return string
         */
        public function getRestNamespace()
        {
            return 'jorgecastro/v' . self::REST_VERSION;
        }

        /**
         * REST endpoint to retrieve logs
         * API key validation handled by permission_callback
         * 
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restLog($request)
        {
            $res = [];
            
            // Ensure log file is initialized
            if (is_null($this->log_file)) {
                $this->jorgecastro_init_log_file();
            }
            
            if (is_readable($this->log_file)) {
                // @phpstan-ignore-next-line
                $res = json_decode('[' . str_replace("}\n", "},", trim(explode('?>', @file_get_contents($this->log_file))[1])) . ']', true);
            }
            return new WP_REST_Response($res, is_array($res) && count($res) > 0 ? 200 : 400);
        }

        /**
         * REST endpoint to receive bulk blog posts from SaaS app
         * API key validation handled by permission_callback
         * 
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restBulkPosts($request)
        {
            $post = $request->get_json_params();

            // Sanitize input data
            $post = $this->sanitizeWebhookData($post);

            // Check if posts array is provided
            if (!isset($post['posts']) || !is_array($post['posts']) || empty($post['posts'])) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'Posts array is required'
                ], 400);
            }

            // Create posts in WordPress
            require_once($this->plugin_path . 'classes/Blog/Handler.php');
            $blogHandler = new \JorgeCastro\Blog\Handler($this);
            $results = $blogHandler->createBulkPosts($post['posts']);

            return new WP_REST_Response([
                'success' => true,
                'results' => $results
            ], 200);
        }

        /**
         * REST endpoint to get all WooCommerce products
         * API key validation handled by permission_callback
         * 
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restWooCommerceProducts($request)
        {

            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'WooCommerce plugin is not installed or activated'
                ], 400);
            }

            // Get query parameters
            $per_page = $request->get_param('per_page') ? absint($request->get_param('per_page')) : 100;
            $page = $request->get_param('page') ? absint($request->get_param('page')) : 1;
            $status = $request->get_param('status') ? sanitize_text_field($request->get_param('status')) : 'any';

            // Validate per_page limit
            if ($per_page > 100) {
                $per_page = 100;
            }

            // Get products using WooCommerce REST API
            $args = [
                'limit' => $per_page,
                'page' => $page,
                'status' => $status,
                'orderby' => 'date',
                'order' => 'DESC',
            ];

            $products = wc_get_products($args);

            if (empty($products)) {
                return new WP_REST_Response([
                    'success' => true,
                    'products' => [],
                    'total' => 0,
                    'page' => $page,
                    'per_page' => $per_page,
                    'total_pages' => 0
                ], 200);
            }

            // Format products data
            $formatted_products = [];
            foreach ($products as $product) {
                $product_data = [
                    'id' => $product->get_id(),
                    'name' => $product->get_name(),
                    'slug' => $product->get_slug(),
                    'type' => $product->get_type(),
                    'status' => $product->get_status(),
                    'featured' => $product->get_featured(),
                    'catalog_visibility' => $product->get_catalog_visibility(),
                    'description' => $product->get_description(),
                    'short_description' => $product->get_short_description(),
                    'sku' => $product->get_sku(),
                    'price' => $product->get_price(),
                    'regular_price' => $product->get_regular_price(),
                    'sale_price' => $product->get_sale_price(),
                    'on_sale' => $product->is_on_sale(),
                    'stock_status' => $product->get_stock_status(),
                    'stock_quantity' => $product->get_stock_quantity(),
                    'manage_stock' => $product->get_manage_stock(),
                    'backorders' => $product->get_backorders(),
                    'weight' => $product->get_weight(),
                    'length' => $product->get_length(),
                    'width' => $product->get_width(),
                    'height' => $product->get_height(),
                    'categories' => [],
                    'tags' => [],
                    'images' => [],
                    'attributes' => [],
                    'date_created' => $product->get_date_created() ? $product->get_date_created()->date('Y-m-d H:i:s') : '',
                    'date_modified' => $product->get_date_modified() ? $product->get_date_modified()->date('Y-m-d H:i:s') : '',
                    'permalink' => $product->get_permalink(),
                ];

                // Get categories
                $categories = wp_get_post_terms($product->get_id(), 'product_cat');
                foreach ($categories as $category) {
                    $product_data['categories'][] = [
                        'id' => $category->term_id,
                        'name' => $category->name,
                        'slug' => $category->slug,
                    ];
                }

                // Get tags
                $tags = wp_get_post_terms($product->get_id(), 'product_tag');
                foreach ($tags as $tag) {
                    $product_data['tags'][] = [
                        'id' => $tag->term_id,
                        'name' => $tag->name,
                        'slug' => $tag->slug,
                    ];
                }

                // Get images
                $image_ids = $product->get_gallery_image_ids();
                if ($product->get_image_id()) {
                    array_unshift($image_ids, $product->get_image_id());
                }
                foreach ($image_ids as $image_id) {
                    $image_url = wp_get_attachment_image_url($image_id, 'full');
                    if ($image_url) {
                        $product_data['images'][] = [
                            'id' => $image_id,
                            'url' => $image_url,
                            'alt' => get_post_meta($image_id, '_wp_attachment_image_alt', true),
                        ];
                    }
                }

                // Get attributes
                $attributes = $product->get_attributes();
                foreach ($attributes as $attribute) {
                    $product_data['attributes'][] = [
                        'id' => $attribute->get_id(),
                        'name' => $attribute->get_name(),
                        'options' => $attribute->get_options(),
                        'visible' => $attribute->get_visible(),
                        'variation' => $attribute->get_variation(),
                    ];
                }

                // For variable products, get variations
                if ($product->get_type() === 'variable') {
                    $variations = $product->get_available_variations();
                    $product_data['variations'] = [];
                    foreach ($variations as $variation) {
                        $product_data['variations'][] = [
                            'id' => $variation['variation_id'],
                            'sku' => $variation['sku'],
                            'price' => $variation['display_price'],
                            'regular_price' => $variation['display_regular_price'],
                            'on_sale' => $variation['is_on_sale'],
                            'stock_status' => $variation['is_in_stock'] ? 'instock' : 'outofstock',
                            'attributes' => $variation['attributes'],
                            'image' => isset($variation['image']) ? $variation['image'] : null,
                        ];
                    }
                }

                $formatted_products[] = $product_data;
            }

            // Get total count for pagination
            $total_products = wp_count_posts('product');
            $total = 0;
            if ($status === 'any' || $status === 'all') {
                $total = array_sum((array) $total_products);
            } elseif (isset($total_products->$status)) {
                $total = (int) $total_products->$status;
            }

            $total_pages = ceil($total / $per_page);

            return new WP_REST_Response([
                'success' => true,
                'products' => $formatted_products,
                'total' => $total,
                'page' => $page,
                'per_page' => $per_page,
                'total_pages' => $total_pages
            ], 200);
        }

        /**
         * REST endpoint to update WooCommerce products via webhook
         * Supports both single product and multiple products
         * API key validation handled by permission_callback
         * 
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restUpdateWooCommerceProducts($request)
        {
            $post = $request->get_json_params();

            // Sanitize input data
            $post = $this->sanitizeWebhookData($post);

            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'WooCommerce plugin is not installed or activated'
                ], 400);
            }

            // Handle different request formats
            $products = null;
            
            // Format 1: { "products": [...] }
            if (isset($post['products']) && is_array($post['products'])) {
                $products = $post['products'];
            }
            // Format 2: Single product object { "id": 123, "name": "...", ... }
            elseif (isset($post['id']) || isset($post['sku'])) {
                $products = [$post];
            }
            // Format 3: Array of products [...]
            elseif (is_array($post) && !empty($post)) {
                // Check if first element has product structure
                if (isset($post[0]) && (isset($post[0]['id']) || isset($post[0]['sku']))) {
                    $products = $post;
                } else {
                    $products = [$post];
                }
            }

            if (empty($products) || !is_array($products)) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'Invalid products data. Provide products array or single product object with id or sku.'
                ], 400);
            }

            // Update products
            require_once($this->plugin_path . 'classes/WooCommerce/Handler.php');
            $wooHandler = new \JorgeCastro\WooCommerce\Handler($this);
            $results = $wooHandler->updateBulkProducts($products);

            return new WP_REST_Response([
                'success' => $results['success'] > 0,
                'results' => $results
            ], $results['success'] > 0 ? 200 : 400);
        }

        /**
         * REST endpoint to get WooCommerce product categories
         * API key validation handled by permission_callback
         *
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restGetWooCommerceCategories($request)
        {

            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'WooCommerce plugin is not installed or activated'
                ], 400);
            }

            // Get query parameters
            $per_page = $request->get_param('per_page') ? absint($request->get_param('per_page')) : 100;
            $page = $request->get_param('page') ? absint($request->get_param('page')) : 1;
            $parent = $request->get_param('parent') ? absint($request->get_param('parent')) : '';
            $hide_empty = $request->get_param('hide_empty') ? (bool) $request->get_param('hide_empty') : false;

            // Validate per_page limit
            if ($per_page > 100) {
                $per_page = 100;
            }

            // Calculate offset for pagination
            $offset = ($page - 1) * $per_page;

            // Get product categories
            $args = [
                'taxonomy' => 'product_cat',
                'orderby' => 'name',
                'order' => 'ASC',
                'hide_empty' => $hide_empty,
                'number' => $per_page,
                'offset' => $offset,
            ];

            if ($parent !== '') {
                $args['parent'] = $parent;
            }

            $categories = get_terms($args);

            if (is_wp_error($categories)) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => $categories->get_error_message()
                ], 400);
            }

            // Format categories data
            $formatted_categories = [];
            foreach ($categories as $category) {
                $formatted_categories[] = [
                    'id' => $category->term_id,
                    'name' => $category->name,
                    'slug' => $category->slug,
                    'description' => $category->description,
                    'parent' => $category->parent,
                    'count' => $category->count,
                    'display_type' => get_term_meta($category->term_id, 'display_type', true),
                    'thumbnail_id' => absint(get_term_meta($category->term_id, 'thumbnail_id', true)),
                    'image' => $this->getCategoryImage($category->term_id),
                ];
            }

            // Get total count for pagination
            $count_args = [
                'taxonomy' => 'product_cat',
                'hide_empty' => $hide_empty,
            ];

            if ($parent !== '') {
                $count_args['parent'] = $parent;
            }

            // Fix deprecated wp_count_terms() - use get_terms() instead
            $count_terms_args = array_merge($count_args, [
                'fields' => 'count',
                'number' => 0,
            ]);
            $total_categories = (int) get_terms($count_terms_args);
            $total_pages = ceil($total_categories / $per_page);

            return new WP_REST_Response([
                'success' => true,
                'categories' => $formatted_categories,
                'total' => $total_categories,
                'page' => $page,
                'per_page' => $per_page,
                'total_pages' => $total_pages
            ], 200);
        }

        /**
         * REST endpoint to create a new WooCommerce product category
         * API key validation handled by permission_callback
         *
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restCreateWooCommerceCategory($request)
        {
            $post = $request->get_json_params();

            // Sanitize input data
            $post = $this->sanitizeWebhookData($post);

            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'WooCommerce plugin is not installed or activated'
                ], 400);
            }

            // Validate required fields
            if (empty($post['name'])) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'Category name is required'
                ], 400);
            }

            // Prepare category data
            $category_data = [
                'name' => sanitize_text_field($post['name']),
                'description' => isset($post['description']) ? wp_kses_post($post['description']) : '',
                'slug' => isset($post['slug']) ? sanitize_title($post['slug']) : '',
                'parent' => isset($post['parent']) ? absint($post['parent']) : 0,
            ];

            // Create the category
            $result = wp_insert_term($category_data['name'], 'product_cat', [
                'description' => $category_data['description'],
                'slug' => $category_data['slug'],
                'parent' => $category_data['parent'],
            ]);

            if (is_wp_error($result)) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => $result->get_error_message()
                ], 400);
            }

            $category_id = $result['term_id'];

            // Set additional metadata
            if (isset($post['display_type'])) {
                update_term_meta($category_id, 'display_type', sanitize_text_field($post['display_type']));
            }

            if (isset($post['image'])) {
                $this->setCategoryImage($category_id, $post['image']);
            }

            // Get the created category data
            $category = get_term($category_id, 'product_cat');

            return new WP_REST_Response([
                'success' => true,
                'category' => [
                    'id' => $category->term_id,
                    'name' => $category->name,
                    'slug' => $category->slug,
                    'description' => $category->description,
                    'parent' => $category->parent,
                    'count' => $category->count,
                    'display_type' => get_term_meta($category->term_id, 'display_type', true),
                    'thumbnail_id' => absint(get_term_meta($category->term_id, 'thumbnail_id', true)),
                    'image' => $this->getCategoryImage($category->term_id),
                ]
            ], 201);
        }

        /**
         * REST endpoint to update a WooCommerce product category
         * API key validation handled by permission_callback
         *
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restUpdateWooCommerceCategory($request)
        {
            $post = $request->get_json_params();
            $category_id = $request->get_param('id');

            // Sanitize input data
            $post = $this->sanitizeWebhookData($post);
            
            // Sanitize category ID parameter
            $category_id = absint($category_id);

            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'WooCommerce plugin is not installed or activated'
                ], 400);
            }

            // Check if category exists
            $category = get_term($category_id, 'product_cat');
            if (!$category || is_wp_error($category)) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'Category not found'
                ], 404);
            }

            // Prepare update data
            $update_data = [];
            $update_args = [];

            if (isset($post['name'])) {
                $update_data['name'] = sanitize_text_field($post['name']);
            }

            if (isset($post['description'])) {
                $update_args['description'] = wp_kses_post($post['description']);
            }

            if (isset($post['slug'])) {
                $update_args['slug'] = sanitize_title($post['slug']);
            }

            if (isset($post['parent'])) {
                $update_args['parent'] = absint($post['parent']);
            }

            // Update the category
            if (!empty($update_data) || !empty($update_args)) {
                $result = wp_update_term($category_id, 'product_cat', array_merge($update_data, $update_args));

                if (is_wp_error($result)) {
                    return new WP_REST_Response([
                        'success' => false,
                        'error' => $result->get_error_message()
                    ], 400);
                }
            }

            // Update additional metadata
            if (isset($post['display_type'])) {
                update_term_meta($category_id, 'display_type', sanitize_text_field($post['display_type']));
            }

            if (isset($post['image'])) {
                $this->setCategoryImage($category_id, $post['image']);
            }

            // Get the updated category data
            $updated_category = get_term($category_id, 'product_cat');

            return new WP_REST_Response([
                'success' => true,
                'category' => [
                    'id' => $updated_category->term_id,
                    'name' => $updated_category->name,
                    'slug' => $updated_category->slug,
                    'description' => $updated_category->description,
                    'parent' => $updated_category->parent,
                    'count' => $updated_category->count,
                    'display_type' => get_term_meta($updated_category->term_id, 'display_type', true),
                    'thumbnail_id' => absint(get_term_meta($updated_category->term_id, 'thumbnail_id', true)),
                    'image' => $this->getCategoryImage($updated_category->term_id),
                ]
            ], 200);
        }

        /**
         * REST endpoint to delete a WooCommerce product category
         * API key validation handled by permission_callback
         *
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restDeleteWooCommerceCategory($request)
        {
            $category_id = $request->get_param('id');

            // Sanitize category ID parameter
            $category_id = absint($category_id);

            // Check if WooCommerce is active
            if (!class_exists('WooCommerce')) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'WooCommerce plugin is not installed or activated'
                ], 400);
            }

            // Check if category exists
            $category = get_term($category_id, 'product_cat');
            if (!$category || is_wp_error($category)) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => 'Category not found'
                ], 404);
            }

            // Delete the category
            $result = wp_delete_term($category_id, 'product_cat');

            if (is_wp_error($result)) {
                return new WP_REST_Response([
                    'success' => false,
                    'error' => $result->get_error_message()
                ], 400);
            }

            return new WP_REST_Response([
                'success' => true,
                'message' => 'Category deleted successfully'
            ], 200);
        }

        /**
         * Get category image URL
         *
         * @param int $category_id
         * @return string|null
         */
        private function getCategoryImage($category_id)
        {
            $thumbnail_id = get_term_meta($category_id, 'thumbnail_id', true);
            if ($thumbnail_id) {
                $image_url = wp_get_attachment_image_url($thumbnail_id, 'full');
                return $image_url ?: null;
            }
            return null;
        }

        /**
         * Set category image from URL
         *
         * @param int $category_id
         * @param string $image_url
         * @return bool
         */
        private function setCategoryImage($category_id, $image_url)
        {
            // Download image if it's a URL
            if (filter_var($image_url, FILTER_VALIDATE_URL)) {
                $attachment_id = $this->downloadImageFromUrl($image_url);
                if ($attachment_id) {
                    update_term_meta($category_id, 'thumbnail_id', $attachment_id);
                    return true;
                }
            } elseif (is_numeric($image_url)) {
                // If it's an attachment ID
                update_term_meta($category_id, 'thumbnail_id', absint($image_url));
                return true;
            }

            return false;
        }

        /**
         * Download image from URL and create attachment
         *
         * @param string $image_url
         * @return int|false Attachment ID on success, false on failure
         */
        private function downloadImageFromUrl($image_url)
        {
            require_once(ABSPATH . 'wp-admin/includes/media.php');
            require_once(ABSPATH . 'wp-admin/includes/file.php');
            require_once(ABSPATH . 'wp-admin/includes/image.php');

            // Download the image
            $temp_file = download_url($image_url);

            if (is_wp_error($temp_file)) {
                return false;
            }

            // Get file name and extension
            $file_array = [
                'name' => basename($image_url),
                'tmp_name' => $temp_file,
            ];

            // Create attachment
            $attachment_id = media_handle_sideload($file_array, 0);

            // Clean up temp file
            @wp_delete_file($temp_file);

            if (is_wp_error($attachment_id)) {
                return false;
            }

            return $attachment_id;
        }

        /**
         * REST endpoint to receive webhooks from SaaS app
         * 
         * @param WP_REST_Request $request
         * @return WP_REST_Response|WP_Error
         */
        public function restWebhook($request)
        {
            $rs = $request->has_valid_params();
            if (is_wp_error($rs)) {
                $this->writeLog([
                    'type' => 'restWebhookValidation',
                    'data' => $rs->get_error_messages(),
                ]);
                return new WP_REST_Response(['message' => $rs->get_error_messages()], 400);
            }

            // WP 4.9 compatibility
            $contentType = $request->get_content_type();
            if (!is_array($contentType) || !isset($contentType['value']) || $contentType['value'] !== 'application/json') {
                $error = 'Wrong Content-Type: ' . (isset($contentType['value']) ? $contentType['value'] : '');

                $this->writeLog([
                    'type' => 'restWebhookContentType',
                    'message' => $error,
                ]);
                return new WP_REST_Response(['message' => $error], 400);
            }

            // Get API key from header
            $header_api_key = $request->get_header('X-API-Key');
            $post_data = $request->get_json_params();
            
            // Sanitize input data
            $post_data = $this->sanitizeWebhookData($post_data);
            
            // Sanitize API key from header
            if ($header_api_key) {
                $post_data['api_key'] = sanitize_text_field($header_api_key);
            }
            
            $ret = $this->webhook($post_data);
            return is_array($ret)
                ? new WP_REST_Response($ret)
                : new WP_REST_Response([
                    'message' => 'You do not have permission to access this resource.',
                ], 400);
        }

        /**
         * Get webhook data from request
         * 
         * Note: This method is only used for internal AJAX webhooks (logged-in admins).
         * REST API endpoints use get_json_params() instead.
         * External services should use REST API endpoints with proper API key authentication.
         * 
         * Security:
         * - Only extracts specific expected fields (action, api_key) - does not process entire input
         * - All input data is sanitized before use
         * - Permission checks are enforced in ajaxWebhook()
         * 
         * @return array Sanitized webhook data with only expected fields
         */
        private function getWebhookData()
        {
            // Define expected fields for webhook actions
            // We only extract these specific fields - not the entire input
            $expected_fields = array('action', 'api_key');
            
            // For AJAX webhooks, data comes from POST body (JSON format)
            // phpcs:ignore WordPress.Security.NonceVerification.Missing -- Nonce check not applicable; capability check enforced in ajaxWebhook(), API key validated in webhook()
            $raw_post = file_get_contents('php://input');
            if (empty($raw_post)) {
                return array();
            }

            // Decode JSON data
            $data = json_decode($raw_post, true);
            if (!is_array($data)) {
                return array();
            }

            // Extract and sanitize ONLY the expected fields
            // This addresses the "processing whole input" security concern
            $sanitized = array();
            foreach ($expected_fields as $field) {
                if (isset($data[$field])) {
                    // Sanitize each field value
                    $sanitized[$field] = sanitize_text_field($data[$field]);
                }
            }
            
            return $sanitized;
        }

        /**
         * Recursively sanitize webhook data
         * 
         * @param mixed $data Data to sanitize
         * @return mixed Sanitized data
         */
        private function sanitizeWebhookData($data)
        {
            if (is_array($data)) {
                $sanitized = [];
                foreach ($data as $key => $value) {
                    // Sanitize array keys - use sanitize_text_field for keys that may contain various characters
                    // sanitize_key is too restrictive (only lowercase, numbers, dashes, underscores)
                    $sanitized_key = sanitize_text_field($key);
                    // Recursively sanitize values
                    $sanitized[$sanitized_key] = $this->sanitizeWebhookData($value);
                }
                return $sanitized;
            } elseif (is_string($data)) {
                // Sanitize strings - use wp_kses_post to allow safe HTML while preventing XSS
                // This preserves HTML content (like blog post content) while removing dangerous scripts
                // Further sanitization will happen in Blog/Handler when processing specific fields
                return wp_kses_post($data);
            } elseif (is_numeric($data)) {
                // Validate and sanitize numbers
                return is_int($data) ? intval($data) : floatval($data);
            } elseif (is_bool($data)) {
                return (bool) $data;
            } elseif (is_null($data)) {
                return null;
            } else {
                // For other types (objects, etc.), return null for safety
                return null;
            }
        }

        /**
         * Handle webhook requests from SaaS app
         * 
         * @param array<string, string> $post Webhook data
         * @return array<string, string>|null
         */
        private function webhook($post)
        {
            $settings = $this->getSettings();
            $action = isset($post['action']) ? sanitize_text_field($post['action']) : '';
            
            // For connect action, verify API key from request
            // For other actions, verify stored API key matches
            $api_key_valid = false;
            if ($action === 'connect' && isset($post['api_key'])) {
                $api_key_valid = true; // Connect action just needs api_key in request
            } elseif (isset($settings['api_key']) && isset($post['api_key']) && $post['api_key'] === $settings['api_key']) {
                $api_key_valid = true;
            }
            
            if ($api_key_valid) {
                    $ret = [
                        'result' => 0,
                        'version' => $this->version,
                    ];

                    // Handle different webhook actions from SaaS app
                    if ($action === 'connect' && isset($post['api_key'])) {
                        $this->setSettings([
                            'api_key' => sanitize_text_field($post['api_key']),
                        ]);
                        $rs = [
                            'result' => 1,
                        ];
                    } elseif ($action === 'disconnect') {
                        $this->deleteSettings();
                        $rs = [
                            'result' => 1
                        ];
                    } else {
                    // Future: Handle other webhook actions
                        $rs = [
                            'error' => 'Plugin does not support this feature'
                        ];
                    }

                    return array_merge($ret, $rs);
            }
            return null;
        }

        /**
         * AJAX webhook handler
         * 
         * Security: This handler is only available to logged-in users (no nopriv).
         * External services should use the REST API endpoints instead.
         * 
         * @return void
         */
        public function ajaxWebhook()
        {
            // Verify user capability
            if (!current_user_can('manage_options')) {
                wp_send_json(array(
                    'error' => __('You do not have permission to perform this action.', 'jorgecastro')
                ), 403);
                return;
            }
            
            // Get and validate webhook data
            $webhook_data = $this->getWebhookData();
            
            // Process webhook
            $ret = $this->webhook($webhook_data);
            if (is_array($ret)) {
                wp_send_json($ret);
            }
            
            wp_send_json(array(
                'error' => __('Invalid request.', 'jorgecastro')
            ), 400);
        }

        /**
         * @return \JorgeCastro\API\Client
         */
        public function getAPIClient()
        {
            if (is_null($this->api_client)) {
                require_once($this->plugin_path . 'classes/API/Client.php');
                $this->api_client = new \JorgeCastro\API\Client($this);
            }
            return $this->api_client;
        }

        public function adminPages()
        {
            include_once($this->plugin_path . 'classes/Admin/SettingsForm.php');
            $form = new \JorgeCastro\Admin\SettingsForm($this);
            $form->init();
        }

        /**
         * Initialize log file in uploads directory (WordPress standard)
         */
        private function jorgecastro_init_log_file()
        {
            $upload_dir = wp_upload_dir();
            $log_dir = $upload_dir['basedir'] . '/jorgecastro';
            
            // Create directory if it doesn't exist
            if (!file_exists($log_dir)) {
                wp_mkdir_p($log_dir);
                // Add .htaccess for security
                @file_put_contents($log_dir . '/.htaccess', "deny from all\n");
            }
            
            $this->log_file = $log_dir . '/log.php';
        }

        /**
         * Write log entry
         * 
         * @param mixed $s Log data
         */
        private function writeLog($s)
        {
            if (!is_array($s)) {
                $s = [
                    'source' => $s,
                ];
            }
            $s['now'] = gmdate('Y-m-d H:i:s');
            
            // Ensure log file is initialized
            if (is_null($this->log_file)) {
                $this->jorgecastro_init_log_file();
            }
            
            if (!file_exists($this->log_file)) {
                @file_put_contents($this->log_file, "<?php die(); ?>\n\n");
            }
            @file_put_contents($this->log_file, jorgecastro_json_encode_unescaped($s) . "\n", FILE_APPEND);
        }

        /**
         * Add filter dropdown to posts list page
         * Shows filter option to display only SAAS-generated posts
         * 
         * @param string $post_type The post type slug
         * @return void
         */
        public function jorgecastro_add_posts_filter($post_type)
        {
            // Only show filter on the 'post' post type
            if ('post' !== $post_type) {
                return;
            }

            // Get current filter value
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin list filter (read-only), nonces not required for restrict_manage_posts hook per WordPress core standards
            $filter_value = isset($_GET['jorgecastro_saas_filter']) ? sanitize_text_field(wp_unslash($_GET['jorgecastro_saas_filter'])) : '';

            // Output filter dropdown
            ?>
            <select name="jorgecastro_saas_filter" id="jorgecastro_saas_filter">
                <option value=""><?php esc_html_e('All Posts', 'jorgecastro'); ?></option>
                <option value="saas_generated" <?php selected($filter_value, 'saas_generated'); ?>>
                    <?php esc_html_e('SAAS Generated Posts', 'jorgecastro'); ?>
                </option>
            </select>
            <?php
        }

        /**
         * Filter posts query to show only SAAS-generated posts when filter is active
         * 
         * @param WP_Query $query The WordPress query object
         * @return void
         */
        public function jorgecastro_filter_posts_by_saas($query)
        {
            // Only run in admin and on main query for posts
            if (!is_admin() || !$query->is_main_query()) {
                return;
            }

            // Only apply to post list page
            $screen = get_current_screen();
            if (!$screen || 'edit-post' !== $screen->id) {
                return;
            }

            // Check if filter is active
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Admin list filter (read-only), nonces not required for pre_get_posts hook per WordPress core standards
            $filter_value = isset($_GET['jorgecastro_saas_filter']) ? sanitize_text_field(wp_unslash($_GET['jorgecastro_saas_filter'])) : '';
            if ('saas_generated' !== $filter_value) {
                return;
            }

            // Add meta query to filter posts with _jorgecastro_ai_generated meta key
            $meta_query = $query->get('meta_query');
            if (!is_array($meta_query)) {
                $meta_query = [];
            }

            $meta_query[] = [
                'key' => '_jorgecastro_ai_generated',
                'value' => '1',
                'compare' => '='
            ];

            $query->set('meta_query', $meta_query);
        }

        /**
         * @static
         * @return JorgeCastro
         */
        public static function i()
        {
            return new JorgeCastro();
        }
    }

    JorgeCastro::i();
}

