<?php
defined('WPINC') || exit;

// Initialize variables to prevent undefined variable errors
if (!isset($jorgecastro_stats)) {
    $jorgecastro_stats = array(
        'total' => 0,
        'published' => 0,
        'drafts' => 0,
    );
}

if (!isset($jorgecastro_content_by_type)) {
    $jorgecastro_content_by_type = array();
}

// Check if connection is established
$jorgecastro_is_connected = $this->plugin->isConnected();

// Sample data - in real implementation, this would come from database
$jorgecastro_stats = array(
    'total' => 0,
    'published' => 0,
    'drafts' => 0,
);

$jorgecastro_content_by_type = array(
    array(
        'title' => __('Meta Title & Description', 'jorgecastro'),
        'total' => 4,
        'published' => 3,
        'drafts' => 0,
    ),
    array(
        'title' => __('Product Category', 'jorgecastro'),
        'total' => 4,
        'published' => 3,
        'drafts' => 0,
    ),
    array(
        'title' => __('Product Text', 'jorgecastro'),
        'total' => 4,
        'published' => 2,
        'drafts' => 2,
    ),
    array(
        'title' => __('Articles', 'jorgecastro'),
        'total' => 4,
        'published' => 2,
        'drafts' => 2,
    ),
    array(
        'title' => __('Blog Posts', 'jorgecastro'),
        'total' => 3,
        'published' => 2,
        'drafts' => 0,
    ),
    array(
        'title' => __('Press Releases', 'jorgecastro'),
        'total' => 3,
        'published' => 2,
        'drafts' => 1,
    ),
    array(
        'title' => __('Youtube Content Brief', 'jorgecastro'),
        'total' => 3,
        'published' => 1,
        'drafts' => 2,
    ),
);

// Calculate totals
if (!isset($jorgecastro_stats)) {
    $jorgecastro_stats = array(
        'total' => 0,
        'published' => 0,
        'drafts' => 0,
    );
}

if (is_array($jorgecastro_content_by_type) && !empty($jorgecastro_content_by_type)) {
    foreach ($jorgecastro_content_by_type as $jorgecastro_type) {
        if (isset($jorgecastro_type['total'])) {
            $jorgecastro_stats['total'] += (int) $jorgecastro_type['total'];
        }
        if (isset($jorgecastro_type['published'])) {
            $jorgecastro_stats['published'] += (int) $jorgecastro_type['published'];
        }
        if (isset($jorgecastro_type['drafts'])) {
            $jorgecastro_stats['drafts'] += (int) $jorgecastro_type['drafts'];
        }
    }
}
?>

<div class="jorgecastro-wrap wrap">
    <div class="jorgecastro-header-new">
        <div>
            <div class="jorgecastro-title-row">
                <h1 class="jorgecastro-main-title"><?php esc_html_e('Content Dashboard', 'jorgecastro'); ?></h1>
            </div>
            <p class="jorgecastro-sub-title"><?php esc_html_e('Overview of all your AI-generated content in WordPress', 'jorgecastro'); ?></p>
        </div>
        <div class="jorgecastro-header-actions">
            <?php if ($jorgecastro_is_connected): ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=jorgecastro-create-content')); ?>" class="ml-btn-create-content">
                    <span class="dashicons dashicons-plus-alt2"></span>
                    <?php esc_html_e('Create Content', 'jorgecastro'); ?>
                </a>
            <?php else: ?>
                <a href="<?php echo esc_url(admin_url('admin.php?page=jorgecastro-settings')); ?>" class="ml-btn-create-content">
                    <span class="dashicons dashicons-admin-links"></span>
                    <?php esc_html_e('Connect', 'jorgecastro'); ?>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="jorgecastro-body">
        <!-- Summary Statistics Row -->
        <div class="ml-dashboard-stats-row">
            <div class="ml-stat-card">
                <div class="ml-stat-icon ml-stat-icon-purple">
                    <span class="dashicons dashicons-chart-bar"></span>
                </div>
                <div class="ml-stat-content">
                    <div class="ml-stat-number"><?php echo esc_html((isset($jorgecastro_stats) && isset($jorgecastro_stats['total'])) ? $jorgecastro_stats['total'] : 0); ?></div>
                    <div class="ml-stat-label"><?php esc_html_e('Total Content', 'jorgecastro'); ?></div>
                </div>
            </div>

            <div class="ml-stat-card">
                <div class="ml-stat-icon ml-stat-icon-green">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <div class="ml-stat-content">
                    <div class="ml-stat-number"><?php echo esc_html((isset($jorgecastro_stats) && isset($jorgecastro_stats['published'])) ? $jorgecastro_stats['published'] : 0); ?></div>
                    <div class="ml-stat-label"><?php esc_html_e('Published', 'jorgecastro'); ?></div>
                </div>
            </div>

            <div class="ml-stat-card">
                <div class="ml-stat-icon ml-stat-icon-blue">
                    <span class="dashicons dashicons-clock"></span>
                </div>
                <div class="ml-stat-content">
                    <div class="ml-stat-number"><?php echo esc_html((isset($jorgecastro_stats) && isset($jorgecastro_stats['drafts'])) ? $jorgecastro_stats['drafts'] : 0); ?></div>
                    <div class="ml-stat-label"><?php esc_html_e('Drafts', 'jorgecastro'); ?></div>
                </div>
            </div>
        </div>

        <!-- Content by Type Section -->
        <div class="ml-content-by-type-section">
            <h2 class="ml-section-heading"><?php esc_html_e('Content by Type', 'jorgecastro'); ?></h2>
            <div class="ml-content-types-grid">
                <?php 
                // Ensure variables are initialized
                if (!isset($jorgecastro_stats)) {
                    $jorgecastro_stats = array(
                        'total' => 0,
                        'published' => 0,
                        'drafts' => 0,
                    );
                }
                if (!isset($jorgecastro_content_by_type) || !is_array($jorgecastro_content_by_type)) {
                    $jorgecastro_content_by_type = array();
                }
                foreach ($jorgecastro_content_by_type as $jorgecastro_type_data): 
                    $jorgecastro_total = $jorgecastro_type_data['total'];
                    $jorgecastro_published = $jorgecastro_type_data['published'];
                    $jorgecastro_drafts = $jorgecastro_type_data['drafts'];
                    $jorgecastro_published_percent = $jorgecastro_total > 0 ? ($jorgecastro_published / $jorgecastro_total) * 100 : 0;
                    $jorgecastro_drafts_percent = $jorgecastro_total > 0 ? ($jorgecastro_drafts / $jorgecastro_total) * 100 : 0;
                ?>
                    <div class="ml-content-type-dashboard-card">
                        <div class="ml-content-type-dashboard-header">
                            <div class="ml-content-type-dashboard-icon">
                                <img src="<?php echo esc_url($this->plugin->plugin_url . 'assets/img/ai-prompt-spark.svg'); ?>" alt="<?php echo esc_attr($jorgecastro_type_data['title']); ?>" class="ml-content-icon-svg-dashboard" />
                            </div>
                            <div class="ml-content-type-dashboard-title">
                                <?php echo esc_html($jorgecastro_type_data['title']); ?>
                            </div>
                        </div>
                        <div class="ml-content-type-dashboard-total">
                            <?php
                            // translators: %d: The total number of content items
                            echo esc_html(sprintf(__('Total: %d', 'jorgecastro'), $jorgecastro_total));
                            ?>
                        </div>
                        <div class="ml-content-type-dashboard-progress">
                            <?php if ($jorgecastro_total > 0): ?>
                                <div class="ml-progress-bar">
                                    <?php if ($jorgecastro_published > 0): ?>
                                        <div class="ml-progress-segment ml-progress-published" style="width: <?php echo esc_attr($jorgecastro_published_percent); ?>%"></div>
                                    <?php endif; ?>
                                    <?php if ($jorgecastro_drafts > 0): ?>
                                        <div class="ml-progress-segment ml-progress-draft" style="width: <?php echo esc_attr($jorgecastro_drafts_percent); ?>%"></div>
                                    <?php endif; ?>
                                </div>
                                <div class="ml-progress-labels">
                                    <?php if ($jorgecastro_published > 0): ?>
                                        <span class="ml-progress-label-published"><?php echo esc_html($jorgecastro_published); ?> <?php esc_html_e('Published', 'jorgecastro'); ?></span>
                                    <?php endif; ?>
                                    <?php if ($jorgecastro_drafts > 0): ?>
                                        <span class="ml-progress-label-draft"><?php echo esc_html($jorgecastro_drafts); ?> <?php esc_html_e('Draft', 'jorgecastro'); ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <div class="ml-progress-bar ml-progress-empty">
                                    <span class="ml-progress-label-empty"><?php esc_html_e('No content yet', 'jorgecastro'); ?></span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
