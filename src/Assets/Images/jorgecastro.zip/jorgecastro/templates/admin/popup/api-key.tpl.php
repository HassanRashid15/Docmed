<?php
/**
 * API Key Connection Popup Template
 * 
 * @package jorgeCastro
 */

defined('WPINC') || exit;
?>

<div id="cg-api-key-popup" class="cg-popup-overlay jorgecastro-hidden">
    <div class="cg-popup-container cg-popup-enhanced">
        <div class="cg-popup-header-new">
            <div>
                <h3 class="cg-popup-title-new"><?php esc_html_e('WordPress Connection', 'jorgecastro'); ?></h3>
                <p class="cg-popup-subtitle-new"><?php esc_html_e('Connect your site to publish content from JorgeCastro AI', 'jorgecastro'); ?></p>
            </div>
            <button type="button" class="cg-popup-close-x" id="cg-close-popup-x">✕</button>
        </div>
        
        <div class="cg-popup-body-new">
            <!-- Instructions Box -->
            <div class="cg-instructions-box">
                <div class="cg-instructions-header">
                    <span class="cg-icon-info-circle"><svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10 18.3333C14.6024 18.3333 18.3334 14.6023 18.3334 9.99996C18.3334 5.39759 14.6024 1.66663 10 1.66663C5.39765 1.66663 1.66669 5.39759 1.66669 9.99996C1.66669 14.6023 5.39765 18.3333 10 18.3333Z" stroke="#9827FC" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10 6.66663V9.99996" stroke="#9827FC" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M10 13.3334H10.0083" stroke="#9827FC" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</span>
                    <h4><?php esc_html_e('How to Get Your API Key', 'jorgecastro'); ?></h4>
                </div>
                <ul class="cg-steps-list">
                    <li>
                        <span class="cg-step-number">1</span>
                        <span><?php echo wp_kses_post( __('Go to <strong>Jorge Castro AI</strong> application settings', 'jorgecastro') ); ?></span>
                    </li>
                    <li>
                        <span class="cg-step-number">2</span>
                        <span><?php echo wp_kses_post( __('Navigate to <strong>Settings → Integrations</strong>', 'jorgecastro') ); ?></span>
                    </li>
                    <li>
                        <span class="cg-step-number">3</span>
                        <span><?php echo wp_kses_post( __('Click <strong>"Connect"</strong> to generate your API key', 'jorgecastro') ); ?></span>
                    </li>
                    <li>
                        <span class="cg-step-number">4</span>
                        <span><?php echo wp_kses_post( __('Copy the API key and paste it below to verify', 'jorgecastro') ); ?></span>
                    </li>
                </ul>
            </div>

            <!-- Warning Box -->
            <div class="cg-warning-box">
                <div class="cg-warning-icon"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 8V12" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 16H12.01" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</div>
                <div class="cg-warning-content">
                    <strong><?php esc_html_e('Connection Required', 'jorgecastro'); ?></strong>
                    <p><?php esc_html_e('Enter your connection key below to verify', 'jorgecastro'); ?>
                
                </p>
                </div>
            </div>

            <!-- Input Field -->
            <div class="cg-input-group">
                <label for="cg_api_key_input" class="cg-input-label"><?php esc_html_e('Paste Connection Key to Verify', 'jorgecastro'); ?></label>
                <input type="text" 
                       id="cg_api_key_input" 
                       class="cg-modern-input" 
                       placeholder="<?php esc_attr_e('Paste your connection key here...', 'jorgecastro'); ?>"
                       autocomplete="off">
            </div>
            
            <div id="cg-api-error" class="cg-error-message jorgecastro-hidden"></div>
        </div>
        
        <div class="cg-popup-footer-new">
            <button type="button" class="cg-btn-text" id="cg-cancel-api-popup">
                <?php esc_html_e('Close', 'jorgecastro'); ?>
            </button>
            <button type="button" class="cg-btn-purple-pill" id="cg-submit-api-key" disabled>
                <span class="dashicons dashicons-yes jorgecastro-icon-18"></span>
                <?php esc_html_e('Verify Connection', 'jorgecastro'); ?>
                <span class="cg-btn-arrow">→</span>
            </button>
        </div>
    </div>
</div>
