<?php
/**
 * Manage Connection Popup Template
 * 
 * @package jorgeCastro
 */

defined('WPINC') || exit;

// Retrieve existing API key
$jorgecastro_settings = $this->plugin->getSettings();
$jorgecastro_current_api_key = isset($jorgecastro_settings['api_key']) ? $jorgecastro_settings['api_key'] : '';
?>

<div id="cg-manage-connection-popup" class="cg-popup-overlay jorgecastro-hidden">
    <div class="cg-popup-container cg-popup-enhanced">
        <div class="cg-popup-header-new">
            <div>
                <h3 class="cg-popup-title-new"><?php esc_html_e('WordPress Connection', 'jorgecastro'); ?></h3>
                <p class="cg-popup-subtitle-new"><?php esc_html_e('Connect your site to publish content from JorgeCastro AI', 'jorgecastro'); ?></p>
            </div>
            <button type="button" class="cg-popup-close-x" id="cg-close-manage-popup-x">✕</button>
        </div>
        
        <div class="cg-popup-body-new">
            <!-- Success Box -->
            <div class="cg-success-box">
                <div class="cg-success-icon-wrapper">
                    <span class="dashicons dashicons-yes-alt"></span>
                </div>
                <div class="cg-success-content">
                    <strong><?php esc_html_e('Connected Successfully ✓', 'jorgecastro'); ?></strong>
                    <p><?php esc_html_e('Your site is ready to receive content from JorgeCastro AI', 'jorgecastro'); ?></p>
                </div>
            </div>

            <!-- Connection Key Section -->
            <div class="cg-input-group">
                <div class="cg-label-row">
                    <label class="cg-input-label"><?php esc_html_e('Your Connection Key', 'jorgecastro'); ?></label>
                    <button type="button" class="cg-show-key-toggle text-button" id="cg-toggle-key-visibility">
                        <span class="dashicons dashicons-visibility"></span> <?php esc_html_e('Show Key', 'jorgecastro'); ?>
                    </button>
                </div>
                <div class="cg-input-wrapper-pill">
                    <input type="password" 
                           id="cg_current_api_key" 
                           class="cg-modern-input-readonly" 
                           value="<?php echo esc_attr($jorgecastro_current_api_key); ?>" 
                           readonly>
                    <button type="button" class="cg-copy-btn" id="cg-copy-api-key" title="<?php esc_attr_e('Copy to clipboard', 'jorgecastro'); ?>">
                        <span class="dashicons dashicons-admin-page"></span>
                    </button>
                </div>
                <p class="cg-input-hint"><?php esc_html_e('Keep this key secure. Do not share it publicly.', 'jorgecastro'); ?></p>
            </div>
            
            <!-- Action Stack -->
            <div class="cg-action-stack">
                <!-- Inline Update Form (Hidden by default) -->
                <div id="cg-inline-update-form" class="cg-inline-update-box jorgecastro-hidden">
                    <div class="cg-update-header">
                        <div class="cg-stack-icon blue small">
                             <span class="dashicons dashicons-edit"></span>
                        </div>
                        <div class="cg-update-title">
                            <strong><?php esc_html_e('Update Connection Key', 'jorgecastro'); ?></strong>
                            <p><?php esc_html_e('Paste your new connection key below', 'jorgecastro'); ?></p>
                        </div>
                    </div>
                    
                    <div class="cg-input-group no-margin">
                        <input type="text" 
                               id="cg_new_api_key_input" 
                               class="cg-modern-input" 
                               placeholder="<?php esc_attr_e('Paste new connection key here...', 'jorgecastro'); ?>"
                               autocomplete="off">
                    </div>

                    <div class="cg-update-actions">
                        <button type="button" class="cg-btn-blue-pill" id="cg-confirm-update-key" disabled>
                           <svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_3_3019)">
<path d="M7.99998 14.6668C11.6819 14.6668 14.6666 11.6821 14.6666 8.00016C14.6666 4.31826 11.6819 1.3335 7.99998 1.3335C4.31808 1.3335 1.33331 4.31826 1.33331 8.00016C1.33331 11.6821 4.31808 14.6668 7.99998 14.6668Z" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6 7.99984L7.33333 9.33317L10 6.6665" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_3_3019">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>

                           <?php esc_html_e('Update Key', 'jorgecastro'); ?>
                        </button>
                        <button type="button" class="cg-btn-text-cancel" id="cg-cancel-update-key">
                            <?php esc_html_e('Cancel', 'jorgecastro'); ?>
                        </button>
                    </div>
                </div>

                <!-- Update Key Button (Visible by default) -->
                <button type="button" class="cg-stack-btn" id="cg-update-key-btn">
                    <div class="cg-stack-icon blue">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M10 2.5H4.16667C3.72464 2.5 3.30072 2.67559 2.98816 2.98816C2.67559 3.30072 2.5 3.72464 2.5 4.16667V15.8333C2.5 16.2754 2.67559 16.6993 2.98816 17.0118C3.30072 17.3244 3.72464 17.5 4.16667 17.5H15.8333C16.2754 17.5 16.6993 17.3244 17.0118 17.0118C17.3244 16.6993 17.5 16.2754 17.5 15.8333V10" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.3125 2.18769C15.644 1.85617 16.0937 1.66992 16.5625 1.66992C17.0313 1.66992 17.481 1.85617 17.8125 2.18769C18.144 2.51921 18.3303 2.96885 18.3303 3.43769C18.3303 3.90653 18.144 4.35617 17.8125 4.68769L10.3017 12.1994C10.1038 12.3971 9.85933 12.5418 9.59083 12.6202L7.19666 13.3202C7.12496 13.3411 7.04895 13.3424 6.97659 13.3238C6.90423 13.3053 6.83819 13.2676 6.78537 13.2148C6.73255 13.162 6.6949 13.096 6.67637 13.0236C6.65783 12.9512 6.65908 12.8752 6.68 12.8035L7.38 10.4094C7.45877 10.1411 7.60378 9.8969 7.80166 9.69936L15.3125 2.18769Z" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
                    </div>
                    <div class="cg-stack-text">
                        <strong><?php esc_html_e('Update Connection Key', 'jorgecastro'); ?></strong>
                        <p><?php esc_html_e('Replace with a new connection key', 'jorgecastro'); ?></p>
                    </div>
                    <span class="cg-stack-arrow">→</span>
                </button>

                <!-- Disconnect -->
                <button type="button" class="cg-stack-btn danger" id="cg-disconnect-btn">
                    <div class="cg-stack-icon red">
                        <svg width="20" height="20" viewBox="0 0 20 20" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_3_2390)">
<path d="M2.5 5H17.5" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M15.8334 5V16.6667C15.8334 17.5 15 18.3333 14.1667 18.3333H5.83335C5.00002 18.3333 4.16669 17.5 4.16669 16.6667V5" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M6.66669 4.99984V3.33317C6.66669 2.49984 7.50002 1.6665 8.33335 1.6665H11.6667C12.5 1.6665 13.3334 2.49984 13.3334 3.33317V4.99984" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8.33331 9.1665V14.1665" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M11.6667 9.1665V14.1665" stroke="white" stroke-width="1.66667" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_3_2390">
<rect width="20" height="20" fill="white"/>
</clipPath>
</defs>
</svg>
                    </div>
                    <div class="cg-stack-text">
                        <strong><?php esc_html_e('Disconnect WordPress', 'jorgecastro'); ?></strong>
                        <p><?php esc_html_e('Remove connection and revoke access', 'jorgecastro'); ?></p>
                    </div>
                    <span class="cg-stack-arrow">→</span>
                </button>
            </div>
        </div>
        
        <div class="cg-popup-footer-new">
            <button type="button" class="cg-btn-text" id="cg-close-manage-popup">
                <?php esc_html_e('Close', 'jorgecastro'); ?>
            </button>
        </div>
    </div>
</div>
