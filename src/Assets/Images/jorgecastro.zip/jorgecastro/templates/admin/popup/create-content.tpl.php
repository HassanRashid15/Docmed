<?php
/**
 * Create Content Popup Template
 * Style: left purple "How it works" + video, right dark form. Fields dynamic by content type.
 *
 * @package jorgeCastro
 */

defined('WPINC') || exit;

$jorgecastro_plugin_url = isset($this) && isset($this->plugin) ? $this->plugin->plugin_url : '';
?>

<div id="jorgecastro-create-content-popup" class="cg-popup-overlay jorgecastro-hidden">
    <div class="jorgecastro-cc-popup-wrap">
        <!-- Left: How it works (purple) -->
        <div class="jorgecastro-cc-popup-left">
            <h3 class="jorgecastro-cc-how-title"><?php esc_html_e('How does it work?', 'jorgecastro'); ?></h3>
            <p class="jorgecastro-cc-how-text"><?php esc_html_e('Click on the video and I\'ll show you step by step.', 'jorgecastro'); ?></p>
            <!-- Video for Title & Description (shown when this content type is selected) -->
            <div class="jorgecastro-cc-video-wrap jorgecastro-cc-video-title-desc jorgecastro-hidden" id="jorgecastro-cc-video-title-desc-wrap">
                <video id="jorgecastro-cc-title-desc-video" class="jorgecastro-cc-video-el" src="https://storage.googleapis.com/jorge_castro/demo/se/meta_data.mp4" controls playsinline preload="metadata" aria-label="<?php echo esc_attr(__('Title & Description guide', 'jorgecastro')); ?>"></video>
            </div>
            <!-- Video for Product Category (shown when this content type is selected) -->
            <div class="jorgecastro-cc-video-wrap jorgecastro-cc-video-category jorgecastro-hidden" id="jorgecastro-cc-video-category-wrap">
                <video id="jorgecastro-cc-category-video" class="jorgecastro-cc-video-el" src="https://storage.googleapis.com/jorge_castro/demo/se/category_page.mp4" controls playsinline preload="metadata" aria-label="<?php echo esc_attr(__('Category page guide', 'jorgecastro')); ?>"></video>
            </div>
            <!-- Default placeholder for other content types -->
            <div class="jorgecastro-cc-video-placeholder" id="jorgecastro-cc-video-placeholder">
                <div class="jorgecastro-cc-video-inner">
                    <span class="jorgecastro-cc-play-icon" aria-hidden="true">&#9658;</span>
                </div>
            </div>
            <div class="jorgecastro-cc-logo">
                <?php if ($jorgecastro_plugin_url) : ?>
                    <img src="<?php echo esc_url($jorgecastro_plugin_url . 'assets/img/jorgecastro-ai.svg'); ?>" alt="jorgecastro.ai" class="jorgecastro-cc-logo-img" />
                <?php endif; ?>
                <span class="jorgecastro-cc-logo-text">jorgecastro.ai</span>
            </div>
        </div>

        <!-- Right: Form (dark) -->
        <div class="jorgecastro-cc-popup-right">
            <button type="button" class="jorgecastro-cc-close-x jorgecastro-create-popup-close" aria-label="<?php echo esc_attr(__('Close', 'jorgecastro')); ?>">&#215;</button>

            <div class="jorgecastro-cc-form-title-row">
                <h2 class="jorgecastro-cc-form-title" id="jorgecastro-create-popup-title">
                    <?php esc_html_e('Create Content', 'jorgecastro'); ?>
                </h2>
                <span class="jorgecastro-cc-form-title-for" id="jorgecastro-create-popup-title-for"></span>
            </div>

            <p class="jorgecastro-cc-steps-text" id="jorgecastro-cc-steps-text"><?php esc_html_e('Follow the steps below to create your content', 'jorgecastro'); ?></p>

            <form id="jorgecastro-create-content-form" class="jorgecastro-create-content-form">
                <input type="hidden" name="content_type" id="jorgecastro-create-content-type" value="" />

                <div class="jorgecastro-create-content-fields">

                    <!-- Title & Description: search term - add keyword on Enter/comma, show as tags -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="title_and_description">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-search-term-input"><?php esc_html_e('Enter a search term', 'jorgecastro'); ?> <span class="required">*</span></label>
                            <div class="jorgecastro-cc-keywords-wrap">
                                <div class="jorgecastro-cc-keywords-tags" id="jorgecastro-cc-keywords-tags"></div>
                                <input type="text" id="jorgecastro-cc-search-term-input" class="jorgecastro-cc-input jorgecastro-cc-keyword-input" placeholder="<?php echo esc_attr(__('Type a keyword and press Enter to add', 'jorgecastro')); ?>" autocomplete="off" />
                                <span class="jorgecastro-cc-counter"><span id="jorgecastro-cc-count">0</span>/1</span>
                            </div>
                            <input type="hidden" name="search_term" id="jorgecastro-cc-search-term" value="" />
                        </p>
                    </div>

                    <!-- Product Category: Target URL + category about (1 phrase, tags) -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="product_category">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-target-url">
                                <?php esc_html_e('Target URL (the page you want to rank)', 'jorgecastro'); ?>
                                <span class="jorgecastro-cc-label-info" aria-label="<?php echo esc_attr(__('Information', 'jorgecastro')); ?>">&#9432;</span>
                            </label>
                            <div class="jorgecastro-cc-input-with-icon jorgecastro-cc-input-link">
                                <span class="dashicons dashicons-admin-links" aria-hidden="true"></span>
                                <input type="url" id="jorgecastro-cc-target-url" name="target_url" class="jorgecastro-cc-input" placeholder="https://" />
                            </div>
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-category-about-input"><?php esc_html_e('What is the category about?', 'jorgecastro'); ?> <span class="required">*</span></label>
                            <div class="jorgecastro-cc-keywords-wrap">
                                <div class="jorgecastro-cc-keywords-tags" id="jorgecastro-cc-category-tags"></div>
                                <input type="text" id="jorgecastro-cc-category-about-input" class="jorgecastro-cc-input jorgecastro-cc-keyword-input" placeholder="<?php echo esc_attr(__("Type 1 search word or phrase - e.g. 'women's training shoes', 'gaming laptops', 'men's knitted sweaters'. Type your word or phrase and press Enter.", 'jorgecastro')); ?>" autocomplete="off" />
                                <span class="jorgecastro-cc-counter"><span id="jorgecastro-cc-category-count">0</span>/1</span>
                            </div>
                            <input type="hidden" name="category_about" id="jorgecastro-cc-category-about" value="" />
                        </p>
                    </div>

                    <!-- Product Text -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="product_text">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-product-name"><?php esc_html_e('Product name', 'jorgecastro'); ?></label>
                            <input type="text" id="jorgecastro-cc-product-name" name="product_name" class="jorgecastro-cc-input" />
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-key-features"><?php esc_html_e('Key features', 'jorgecastro'); ?></label>
                            <textarea id="jorgecastro-cc-key-features" name="key_features" class="jorgecastro-cc-textarea" rows="4"></textarea>
                        </p>
                    </div>

                    <!-- Article -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="article">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-article-topic"><?php esc_html_e('Topic', 'jorgecastro'); ?></label>
                            <input type="text" id="jorgecastro-cc-article-topic" name="topic" class="jorgecastro-cc-input" />
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-article-tone"><?php esc_html_e('Tone', 'jorgecastro'); ?></label>
                            <select id="jorgecastro-cc-article-tone" name="tone" class="jorgecastro-cc-input">
                                <option value="professional"><?php esc_html_e('Professional', 'jorgecastro'); ?></option>
                                <option value="friendly"><?php esc_html_e('Friendly', 'jorgecastro'); ?></option>
                                <option value="casual"><?php esc_html_e('Casual', 'jorgecastro'); ?></option>
                            </select>
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-article-words"><?php esc_html_e('Word count', 'jorgecastro'); ?></label>
                            <input type="number" id="jorgecastro-cc-article-words" name="word_count" min="100" value="500" class="jorgecastro-cc-input jorgecastro-cc-input-small" />
                        </p>
                    </div>

                    <!-- Blog Post -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="blog_post">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-blog-topic"><?php esc_html_e('Topic', 'jorgecastro'); ?></label>
                            <input type="text" id="jorgecastro-cc-blog-topic" name="topic" class="jorgecastro-cc-input" />
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-blog-tone"><?php esc_html_e('Tone', 'jorgecastro'); ?></label>
                            <select id="jorgecastro-cc-blog-tone" name="tone" class="jorgecastro-cc-input">
                                <option value="professional"><?php esc_html_e('Professional', 'jorgecastro'); ?></option>
                                <option value="friendly"><?php esc_html_e('Friendly', 'jorgecastro'); ?></option>
                                <option value="casual"><?php esc_html_e('Casual', 'jorgecastro'); ?></option>
                            </select>
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-blog-words"><?php esc_html_e('Word count', 'jorgecastro'); ?></label>
                            <input type="number" id="jorgecastro-cc-blog-words" name="word_count" min="100" value="800" class="jorgecastro-cc-input jorgecastro-cc-input-small" />
                        </p>
                    </div>

                    <!-- Press Release -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="press_release">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-headline"><?php esc_html_e('Headline', 'jorgecastro'); ?></label>
                            <input type="text" id="jorgecastro-cc-headline" name="headline" class="jorgecastro-cc-input" />
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-key-points"><?php esc_html_e('Key points', 'jorgecastro'); ?></label>
                            <textarea id="jorgecastro-cc-key-points" name="key_points" class="jorgecastro-cc-textarea" rows="4"></textarea>
                        </p>
                    </div>

                    <!-- YouTube Content Brief -->
                    <div class="jorgecastro-field-group jorgecastro-hidden" data-content-type="youtube_content_brief">
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-video-topic"><?php esc_html_e('Video topic', 'jorgecastro'); ?></label>
                            <input type="text" id="jorgecastro-cc-video-topic" name="video_topic" class="jorgecastro-cc-input" />
                        </p>
                        <p class="jorgecastro-field-row">
                            <label for="jorgecastro-cc-duration"><?php esc_html_e('Duration (minutes)', 'jorgecastro'); ?></label>
                            <input type="number" id="jorgecastro-cc-duration" name="duration" min="1" value="5" class="jorgecastro-cc-input jorgecastro-cc-input-small" />
                        </p>
                    </div>
                </div>

                <p class="jorgecastro-cc-credits">1 <?php esc_html_e('unit', 'jorgecastro'); ?> &bull; 10 <?php esc_html_e('credits', 'jorgecastro'); ?></p>

                <div class="jorgecastro-cc-actions">
                    <button type="button" class="jorgecastro-cc-btn jorgecastro-cc-btn-close jorgecastro-create-popup-close">
                        <span class="dashicons dashicons-arrow-left-alt2"></span>
                        <?php esc_html_e('Close', 'jorgecastro'); ?>
                    </button>
                    <button type="submit" class="jorgecastro-cc-btn jorgecastro-cc-btn-create">
                        <?php esc_html_e('Create', 'jorgecastro'); ?>
                        <span class="dashicons dashicons-arrow-right-alt2"></span>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
