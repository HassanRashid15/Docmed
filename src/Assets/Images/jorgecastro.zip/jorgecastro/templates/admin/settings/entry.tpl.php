<?php
defined('WPINC') || exit;
?>

<div class="jorgecastro-wrap wrap">
    <div class="jorgecastro-header-new">
        <div>
            <div class="jorgecastro-title-row">
                <h1 class="jorgecastro-main-title">AI Agent For SEO by JorgeCastro.AI</h1>
                <div class="jorgecastro-flex-center">
               
                <span class="jorgecastro-status-badge"> <svg width="15" height="15" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M6 1.5L5.044 4.4065C4.99507 4.55525 4.9119 4.69044 4.80117 4.80117C4.69044 4.9119 4.55525 4.99507 4.4065 5.044L1.5 6L4.4065 6.956C4.55525 7.00493 4.69044 7.0881 4.80117 7.19883C4.9119 7.30956 4.99507 7.44475 5.044 7.5935L6 10.5L6.956 7.5935C7.00493 7.44475 7.0881 7.30956 7.19883 7.19883C7.30956 7.0881 7.44475 7.00493 7.5935 6.956L10.5 6L7.5935 5.044C7.44475 4.99507 7.30956 4.9119 7.19883 4.80117C7.0881 4.69044 7.00493 4.55525 6.956 4.4065L6 1.5Z" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M2.5 1.5V3.5" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M9.5 8.5V10.5" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M1.5 2.5H3.5" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8.5 9.5H10.5" stroke="white" stroke-linecap="round" stroke-linejoin="round"/>
</svg>ACTIVE</span>
                </div>
            </div>
            <p class="jorgecastro-sub-title">Instantly publish SEO-optimized content from Jorge Castro to WordPress.</p>
        </div>
        <?php if ($this->plugin->isConnected()): ?>
        <div class="jorgecastro-header-actions">
           <button class="jorgecastro-connected-badge-btn">
               <span class="jorgecastro-dot-indicator"></span>
               <?php esc_html_e('Connected JorgeCastro AI', 'jorgecastro'); ?>
               <span class="dashicons dashicons-yes-alt jorgecastro-badge-icon"></span>
           </button>
        </div>
        <?php endif; ?>
    </div>

    <div class="jorgecastro-body">
        <?php require $this->plugin->plugin_path . "templates/admin/settings/general.tpl.php"; ?>
    </div>
</div>