<?php
defined('WPINC') || exit;

$jorgecastro_btn_txt = __('Connect Now', 'jorgecastro');
$jorgecastro_connection_type = __('not', 'jorgecastro');
$jorgecastro_connected = false;
if ($this->plugin->isConnected()) {
    $jorgecastro_btn_txt = __('Disconnect', 'jorgecastro');
    $jorgecastro_connection_type = '';
    $jorgecastro_connected = true;
}
?>
<!-- Toast Notification Container -->
<div id="ml-toast-container" class="ml-toast-container"></div>

<div class="jorgecastro_msg jorgecastro-hidden"><?php echo esc_html($this->showMessages()); ?></div>

<div class="ml-main-container">
    <!-- Connection Status Card -->
    <div class="ml-card ml-status-card-new <?php echo $jorgecastro_connected ? 'connected-green' : '' ; ?>" id="jorgecastro-connection-card">
        <div class="ml-status-card-content">
            <div class="ml-status-icon-wrapper">
                <?php if ($jorgecastro_connected): ?>
                    <span class="ml-icon-status ml-icon-check-circle-green"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16 29.3334C23.3638 29.3334 29.3333 23.3639 29.3333 16.0001C29.3333 8.63628 23.3638 2.66675 16 2.66675C8.63619 2.66675 2.66666 8.63628 2.66666 16.0001C2.66666 23.3639 8.63619 29.3334 16 29.3334Z" stroke="#00C950" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M12 15.9999L14.6667 18.6666L20 13.3333" stroke="#00C950" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</span>
                <?php else: ?>
                    <span class="ml-icon-status ml-icon-alert-circle"><svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M16 29.3333C23.3638 29.3333 29.3333 23.3638 29.3333 16C29.3333 8.63616 23.3638 2.66663 16 2.66663C8.63619 2.66663 2.66666 8.63616 2.66666 16C2.66666 23.3638 8.63619 29.3333 16 29.3333Z" stroke="#9827FC" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16 10.6666V16" stroke="#9827FC" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M16 21.3334H16.0133" stroke="#9827FC" stroke-width="2.66667" stroke-linecap="round" stroke-linejoin="round"/>
</svg>
</span>
                <?php endif; ?>
            </div>
            <div class="ml-status-text">
                <h2 class="ml-status-heading">
                    <?php echo esc_html($jorgecastro_connected ? __("You're All Set! 🎉", 'jorgecastro') : __('Complete Your Connection', 'jorgecastro')); ?>
                </h2>
                <p class="ml-status-subtext">
                    <?php echo esc_html($jorgecastro_connected 
                        ? __('Your WordPress site is connected. Content from Castro will be published automatically according to your preferences.', 'jorgecastro') 
                        : __('Finalize your connection to start publishing content from Castro directly to your WordPress site with one click.', 'jorgecastro')); 
                    ?>
                </p>
                <div class="ml-status-action-row">
                    <?php if ($jorgecastro_connected): ?>
                        <a href="#disconnect" 
                          id="jorgecastro_connection_button" 
                          class="ml-btn-glass-green">
                           <span class="jorgecastro-inline-flex-center"><svg width="20" height="20" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_3_1676)">
<path d="M6.44732 2.75735C6.48406 2.37091 6.66354 2.01205 6.95072 1.75087C7.2379 1.4897 7.61214 1.34497 8.00032 1.34497C8.3885 1.34497 8.76274 1.4897 9.04992 1.75087C9.3371 2.01205 9.51659 2.37091 9.55332 2.75735C9.5754 3.00699 9.6573 3.24763 9.79208 3.45891C9.92686 3.67019 10.1106 3.84589 10.3276 3.97114C10.5447 4.09638 10.7888 4.16749 11.0391 4.17843C11.2895 4.18938 11.5388 4.13984 11.766 4.03402C12.1187 3.87387 12.5184 3.8507 12.8873 3.96901C13.2562 4.08732 13.5679 4.33865 13.7617 4.67409C13.9555 5.00953 14.0175 5.40507 13.9358 5.78373C13.854 6.1624 13.6343 6.4971 13.3193 6.72269C13.1142 6.86658 12.9468 7.05776 12.8313 7.28004C12.7157 7.50231 12.6554 7.74916 12.6554 7.99969C12.6554 8.25021 12.7157 8.49706 12.8313 8.71934C12.9468 8.94161 13.1142 9.13279 13.3193 9.27669C13.6343 9.50228 13.854 9.83697 13.9358 10.2156C14.0175 10.5943 13.9555 10.9898 13.7617 11.3253C13.5679 11.6607 13.2562 11.9121 12.8873 12.0304C12.5184 12.1487 12.1187 12.1255 11.766 11.9654C11.5388 11.8595 11.2895 11.81 11.0391 11.8209C10.7888 11.8319 10.5447 11.903 10.3276 12.0282C10.1106 12.1535 9.92686 12.3292 9.79208 12.5405C9.6573 12.7517 9.5754 12.9924 9.55332 13.242C9.51659 13.6285 9.3371 13.9873 9.04992 14.2485C8.76274 14.5097 8.3885 14.6544 8.00032 14.6544C7.61214 14.6544 7.2379 14.5097 6.95072 14.2485C6.66354 13.9873 6.48406 13.6285 6.44732 13.242C6.42529 12.9923 6.34339 12.7516 6.20857 12.5402C6.07375 12.3288 5.88997 12.1531 5.67281 12.0278C5.45565 11.9026 5.2115 11.8315 4.96104 11.8206C4.71058 11.8097 4.46119 11.8594 4.23399 11.9654C3.88125 12.1255 3.48154 12.1487 3.11266 12.0304C2.74377 11.9121 2.4321 11.6607 2.23831 11.3253C2.04452 10.9898 1.98247 10.5943 2.06423 10.2156C2.14599 9.83697 2.36572 9.50228 2.68066 9.27669C2.88574 9.13279 3.05314 8.94161 3.16872 8.71934C3.28429 8.49706 3.34463 8.25021 3.34463 7.99969C3.34463 7.74916 3.28429 7.50231 3.16872 7.28004C3.05314 7.05776 2.88574 6.86658 2.68066 6.72269C2.36617 6.49698 2.14682 6.16242 2.06526 5.78401C1.98369 5.4056 2.04573 5.01038 2.23931 4.67516C2.4329 4.33994 2.7442 4.08867 3.11272 3.97018C3.48123 3.85169 3.88065 3.87444 4.23332 4.03402C4.46049 4.13984 4.70982 4.18938 4.96019 4.17843C5.21056 4.16749 5.45461 4.09638 5.67168 3.97114C5.88875 3.84589 6.07245 3.67019 6.20723 3.45891C6.34202 3.24763 6.42391 3.00699 6.44599 2.75735" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8 10C9.10457 10 10 9.10457 10 8C10 6.89543 9.10457 6 8 6C6.89543 6 6 6.89543 6 8C6 9.10457 6.89543 10 8 10Z" stroke="white" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_3_1676">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>
</span>
                            <?php echo esc_html__('Manage Connection', 'jorgecastro'); ?>
                        </a>
                    <?php else: ?>
                        <a href="#connect"
   id="jorgecastro_connection_button"
   class="ml-btn-pill">

    <span class="ml-btn-icon-globe">
        <span class="dashicons dashicons-admin-site"></span>
    </span>

    <?php echo esc_html($jorgecastro_btn_txt); ?>
    <span class="ml-btn-arrow">→</span>
</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <?php
        // Check SEO plugin status
        if (!function_exists('is_plugin_active')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }
        $jorgecastro_yoast_active = is_plugin_active('wordpress-seo/wp-seo.php') || is_plugin_active('wordpress-seo-premium/wp-seo-premium.php');
        $jorgecastro_rank_math_active = is_plugin_active('seo-by-rank-math/rank-math.php');
        $jorgecastro_seo_plugin_detected = $jorgecastro_yoast_active || $jorgecastro_rank_math_active;
        ?>
        <div class="ml-seo-hr-divider">
            <hr class="ml-seo-hr">
        </div>
        <div class="ml-seo-status-bar">
            <div class="ml-seo-left">
                <?php if (!$jorgecastro_connected): ?>
                <div class="ml-seo-plugin-icons">
                    <div class="ml-seo-plugin-icon-wrapper <?php echo $jorgecastro_yoast_active ? 'ml-seo-plugin-active' : ''; ?>">
                        <img src="<?php echo esc_url($this->plugin->plugin_url . 'assets/img/yoast1.png'); ?>" alt="Yoast SEO" class="ml-seo-plugin-icon" />
                        <?php if ($jorgecastro_yoast_active): ?>
                            <span class="ml-seo-checkmark">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 14.6667C11.6819 14.6667 14.6667 11.6819 14.6667 8C14.6667 4.3181 11.6819 1.33333 8 1.33333C4.3181 1.33333 1.33333 4.3181 1.33333 8C1.33333 11.6819 4.3181 14.6667 8 14.6667Z" fill="#00C950"/>
                                    <path d="M6 8L7.33333 9.33333L10 6.66667" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div class="ml-seo-plugin-icon-wrapper <?php echo $jorgecastro_rank_math_active ? 'ml-seo-plugin-active' : ''; ?>">
                        <img src="<?php echo esc_url($this->plugin->plugin_url . 'assets/img/upscale.png'); ?>" alt="Rank Math SEO" class="ml-seo-plugin-icon" />
                        <?php if ($jorgecastro_rank_math_active): ?>
                            <span class="ml-seo-checkmark">
                                <svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M8 14.6667C11.6819 14.6667 14.6667 11.6819 14.6667 8C14.6667 4.3181 11.6819 1.33333 8 1.33333C4.3181 1.33333 1.33333 4.3181 1.33333 8C1.33333 11.6819 4.3181 14.6667 8 14.6667Z" fill="#00C950"/>
                                    <path d="M6 8L7.33333 9.33333L10 6.66667" stroke="white" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
                                </svg>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
                <div class="ml-seo-info">
                    <div class="ml-seo-label-row">
                        <span class="ml-seo-label"><?php echo $jorgecastro_seo_plugin_detected ? esc_html__('SEO Plugin Detected', 'jorgecastro') : esc_html__('SEO Plugin Required', 'jorgecastro'); ?></span>
                        <?php if (!$jorgecastro_seo_plugin_detected): ?>
                            <span class="ml-seo-exclamation-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_1_464)">
<path d="M7.99998 14.6666C11.6819 14.6666 14.6666 11.6819 14.6666 7.99998C14.6666 4.31808 11.6819 1.33331 7.99998 1.33331C4.31808 1.33331 1.33331 4.31808 1.33331 7.99998C1.33331 11.6819 4.31808 14.6666 7.99998 14.6666Z" stroke="#FB2C36" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8 5.33331V7.99998" stroke="#FB2C36" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M8 10.6667H8.00667" stroke="#FB2C36" stroke-width="1.33333" stroke-linecap="round" stroke-linejoin="round"/>
</g>
<defs>
<clipPath id="clip0_1_464">
<rect width="16" height="16" fill="white"/>
</clipPath>
</defs>
</svg>
</span>
                        <?php endif; ?>
                    </div>
                    <span class="ml-seo-desc">
                         <?php 
                        if ($jorgecastro_yoast_active) {
                            echo esc_html__('Yoast SEO is active for meta optimization', 'jorgecastro');
                        } elseif ($jorgecastro_rank_math_active) {
                            echo esc_html__('Rank Math SEO is active for meta optimization', 'jorgecastro');
                        } else {
                            echo esc_html__('Install Yoast SEO or Rank Math SEO for meta optimization', 'jorgecastro');
                        }
                        ?>
                    </span>
                </div>
            </div>
            
            <?php if (!$jorgecastro_seo_plugin_detected): ?>
            <div class="ml-seo-right">
                <a href="<?php echo esc_url(admin_url('plugin-install.php?s=yoast+seo&tab=search&type=term')); ?>" target="_blank" class="ml-btn-glass">
                    <?php echo esc_html__('Install Plugin', 'jorgecastro'); ?> →
                </a>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Quick Actions -->
    <div class="ml-quick-actions-section box-white">
        <h3 class="ml-section-heading"><?php echo esc_html__('Quick Actions', 'jorgecastro'); ?></h3>
        
        <div class="ml-quick-actions-grid">
            <!-- Action 1: Create Content -->
            <a href="<?php echo esc_url(admin_url('admin.php?page=jorgecastro-create-content')); ?>" class="ml-action-card ml-action-link">
                <div class="ml-action-icon-box ml-icon-orange">
                    <span class="dashicons dashicons-edit"></span>
                </div>
                <h4 class="ml-action-title"><?php echo esc_html__('Create Content', 'jorgecastro'); ?></h4>
                <p class="ml-action-desc"><?php echo esc_html__('Generate new content', 'jorgecastro'); ?></p>
            </a>
            
            <!-- Action 2: Connection -->
            <div class="ml-action-card">
                <div class="ml-action-icon-box ml-icon-purple">
                    <span class="dashicons dashicons-admin-site-alt3"></span>
                </div>
                <h4 class="ml-action-title"><?php echo esc_html__('Connection', 'jorgecastro'); ?></h4>
                <p class="ml-action-desc"><?php echo esc_html__('Manage your connection', 'jorgecastro'); ?></p>
            </div>
            
            <!-- Action 3: Settings -->
            <div class="ml-action-card">
                <div class="ml-action-icon-box ml-icon-blue">
                    <span class="dashicons dashicons-admin-settings"></span>
                </div>
                <h4 class="ml-action-title"><?php echo esc_html__('Settings', 'jorgecastro'); ?></h4>
                <p class="ml-action-desc"><?php echo esc_html__('Configure preferences', 'jorgecastro'); ?></p>
            </div>
            
            <!-- Action 4: Visit Application -->
            <a href="https://jorgecastro.ai/" target="_blank" class="ml-action-card ml-action-link">
                <div class="ml-action-icon-box ml-icon-green">
                    <span class="dashicons dashicons-external"></span>
                </div>
                <h4 class="ml-action-title"><?php echo esc_html__('Visit Application', 'jorgecastro'); ?></h4>
                <p class="ml-action-desc"><?php echo esc_html__('Open JorgeCastro AI', 'jorgecastro'); ?></p>
            </a>
        </div>
    </div>
</div>
