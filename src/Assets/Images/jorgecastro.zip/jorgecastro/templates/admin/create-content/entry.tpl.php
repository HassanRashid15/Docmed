<?php
defined('WPINC') || exit;

// Content types array: slug used for popup field groups
$jorgecastro_content_types = array(
    array(
        'slug' => 'title_and_description',
        'title' => __('Title & Description', 'jorgecastro'),
        'desc' => __('Create the title and short summary that shows in search results to make your page more attractive and easier to find.', 'jorgecastro'),
    ),
    array(
        'slug' => 'product_category',
        'title' => __('Product Category', 'jorgecastro'),
        'desc' => __('Describe your product categories to help shoppers easily navigate and find the products they\'re looking for.', 'jorgecastro'),
    ),
    array(
        'slug' => 'product_text',
        'title' => __('Product Text', 'jorgecastro'),
        'desc' => __('Provide clear and helpful details about your product, highlighting its features and benefits for customers.', 'jorgecastro'),
    ),
    array(
        'slug' => 'article',
        'title' => __('Article', 'jorgecastro'),
        'desc' => __('Write a friendly, easy-to-read article that shares interesting ideas and useful information with your audience.', 'jorgecastro'),
    ),
    array(
        'slug' => 'blog_post',
        'title' => __('Blog Post', 'jorgecastro'),
        'desc' => __('Create an engaging blog post that feels personal and invites readers to explore your stories and insights.', 'jorgecastro'),
    ),
    array(
        'slug' => 'press_release',
        'title' => __('Press Release', 'jorgecastro'),
        'desc' => __('Share important news or announcements in a clear and professional way that grabs the attention of the public.', 'jorgecastro'),
    ),
    array(
        'slug' => 'youtube_content_brief',
        'title' => __('YouTube Content Brief', 'jorgecastro'),
        'desc' => __('Outline the key points for your YouTube video, ensuring your content is clear, on-message, and engaging for viewers.', 'jorgecastro'),
    ),
);
?>

<div class="jorgecastro-wrap wrap">
    <div class="jorgecastro-header-new">
        <div>
            <div class="jorgecastro-title-row">
                <h1 class="jorgecastro-main-title"><?php esc_html_e('Create Content', 'jorgecastro'); ?></h1>
            </div>
            <p class="jorgecastro-sub-title"><?php esc_html_e('Choose a content type to generate AI-powered content for your WordPress site.', 'jorgecastro'); ?></p>
        </div>
    </div>

    <div class="jorgecastro-body">
        <div class="ml-content-types-grid">
            <?php foreach ($jorgecastro_content_types as $jorgecastro_type_data): ?>
                <div class="ml-content-type-card">
                    <div class="ml-content-type-icon">
                        <div class="ml-content-icon-bg">
                            <img src="<?php echo esc_url($this->plugin->plugin_url . 'assets/img/ai-prompt-spark.svg'); ?>" alt="<?php echo esc_attr($jorgecastro_type_data['title']); ?>" class="ml-content-icon-svg" />
                        </div>
                    </div>
                    <h3 class="ml-content-type-title"><?php echo esc_html($jorgecastro_type_data['title']); ?></h3>
                    <p class="ml-content-type-desc"><?php echo esc_html($jorgecastro_type_data['desc']); ?></p>
                    <button type="button" class="ml-content-type-link jorgecastro-open-create-popup" data-content-type="<?php echo esc_attr($jorgecastro_type_data['slug']); ?>" data-title="<?php echo esc_attr($jorgecastro_type_data['title']); ?>"><?php esc_html_e('Create Content', 'jorgecastro'); ?> →</button>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>
