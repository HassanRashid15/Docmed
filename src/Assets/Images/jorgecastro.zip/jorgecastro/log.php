<?php
/**
 * jorgeCastro Log File
 * 
 * This file is used to store runtime logs for the jorgeCastro plugin.
 * 
 * @package jorgeCastro
 */

defined('WPINC') || exit;

// Log entries will be appended below this line.
