<?php

/**
 * Utility functions for jorgeCastro plugin
 */

// If this file is called directly, abort.
defined('WPINC') || exit;

if (!function_exists('jorgecastro_json_encode_unescaped')) {
    /**
     * JSON encode with unescaped unicode
     * 
     * @param mixed $payload Data to encode
     * @return string JSON string
     */
    function jorgecastro_json_encode_unescaped($payload)
    {
        return (string)@json_encode($payload, JSON_UNESCAPED_UNICODE);
    }
}

