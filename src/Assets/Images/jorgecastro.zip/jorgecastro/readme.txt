=== JorgeCastro ===
Contributors: castromind
Tags: ai content, blog automation, seo, content publishing, jorgeCastro
Tested up to: 6.9
Requires at least: 5.0
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Connect your WordPress site to jorgeCastro and receive AI-generated blog posts directly from your SaaS dashboard.

== Description ==

jorgeCastro is a WordPress plugin that connects your site to the jorgeCastro SaaS platform, allowing you to receive and publish AI-generated blog posts seamlessly.

**Key Features:**

* **Easy Connection** - Connect your WordPress site to jorgeCastro with a single API key.
* **Auto Publish** - Receive blog posts directly from jorgeCastro SaaS and publish them automatically.
* **Image Handling** - Automatically downloads images from posts and sets featured images.
* **SEO Integration** - Supports Yoast SEO and Rank Math for automatic meta tag assignment.
* **Flexible Status** - Posts can be published, saved as draft, pending, or private based on your preference.

== Installation ==

1. Upload the plugin folder to `/wp-content/plugins/jorgeCastro/` or install via WordPress plugin uploader.
2. Activate **jorgeCastro** from the Plugins screen.
3. Navigate to **Settings → jorgeCastro** to connect your site.
4. Enter your API key from your jorgeCastro dashboard and click **Connect Now**.
5. Start sending blog posts from jorgeCastro SaaS to your WordPress site!

== Frequently Asked Questions ==

= How do I get an API key? =
Login to your jorgeCastro dashboard, navigate to Settings → API Keys, and generate a new API key.

= Which SEO plugins are supported? =
jorgeCastro supports Yoast SEO and Rank Math. SEO meta tags (title, description, keywords) will be automatically assigned when these plugins are active.

= Can I control post status? =
Yes! Posts can be set to publish, draft, pending, or private from the jorgeCastro SaaS when sending to WordPress.

= Are images handled automatically? =
Yes, all images in the content are automatically downloaded to your WordPress media library, and the first image can be set as the featured image.

== Screenshots ==

1. Plugin settings page with connection status
2. API key connection popup
3. SEO plugin detection status

== Changelog ==

= 1.0.0 =
* Initial release
* Connect/disconnect to jorgeCastro SaaS
* Receive and publish blog posts via REST API
* Automatic image downloading and featured image support
* SEO integration with Yoast SEO and Rank Math
* Categories and tags support
* Flexible post status (publish, draft, pending, private)

== Upgrade Notice ==

= 1.0.0 =
Initial release of jorgeCastro WordPress plugin.
