<?php

namespace JorgeCastro\Admin;

defined('WPINC') || exit;

class SettingsForm
{
    /** @var \JorgeCastro */
    private $plugin;

    public function __construct($plugin)
    {
        $this->plugin = $plugin;
    }

    public function init()
    {
        add_action('admin_menu', [$this, 'menu_page'], 20);
        if (wp_doing_ajax()) {
            add_action('wp_ajax_jorgecastro_app_connection', [$this, 'connectionAjax']);
        }
    }

    /**
     * Render API Key popup template
     */
    public function renderApiKeyPopup()
    {
        require_once $this->plugin->plugin_path . 'templates/admin/popup/api-key.tpl.php';
        require_once $this->plugin->plugin_path . 'templates/admin/popup/manage-connection.tpl.php';
    }

    public function menu_page()
    {
        $page = add_menu_page(
            'jorgeCastro Settings',
            'JORGECASTRO AI',
            'manage_options',
            'jorgecastro-setting',
            [$this, 'render_page'],
            $this->plugin->plugin_url . 'assets/img/jorgecastro-ai.svg',
            30
        );

        // Add Dashboard submenu (first item - default, uses same slug as main menu)
        $dashboard_page = add_submenu_page(
            'jorgecastro-setting',
            'Content Dashboard',
            'Dashboard',
            'manage_options',
            'jorgecastro-setting', // Use same slug as main page to make it default
            [$this, 'render_dashboard_page']
        );

        // Add Settings submenu
        $settings_page = add_submenu_page(
            'jorgecastro-setting',
            'Settings',
            'Settings',
            'manage_options',
            'jorgecastro-settings',
            [$this, 'render_settings_page']
        );

        // Add Create Content submenu
        $create_content_page = add_submenu_page(
            'jorgecastro-setting',
            'Create Content',
            'Create Content',
            'manage_options',
            'jorgecastro-create-content',
            [$this, 'render_create_content_page']
        );

        add_action('load-' . $page, [$this, 'initSettingsPage']);
        add_action('load-' . $create_content_page, [$this, 'initCreateContentPage']);
        add_action('load-' . $dashboard_page, [$this, 'initDashboardPage']);
        add_action('load-' . $settings_page, [$this, 'initSettingsPage']);
    }

    public function initSettingsPage()
    {
        // Use minified files in production, unminified for debugging
        $suffix = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
        
        wp_enqueue_script('jorgecastro-settings',
            $this->plugin->plugin_url . 'assets/js/settings.js',
            ['jquery'],
            $this->plugin->version,
            true
        );
        
        wp_enqueue_style('jorgecastro-admin-css',
            $this->plugin->plugin_url . 'assets/css/admin.css',
            [],
            $this->plugin->version
        );
        
        wp_localize_script('jorgecastro-settings', 'jorgecastro_ajax', [
            'nonce' => wp_create_nonce('jorgecastro_ajax_nonce'),
            'ajaxurl' => admin_url('admin-ajax.php'),
        ]);
        
        // Add popup to admin footer
        add_action('admin_footer', [$this, 'renderApiKeyPopup']);
    }

    public function initCreateContentPage()
    {
        wp_enqueue_style('jorgecastro-admin-css',
            $this->plugin->plugin_url . 'assets/css/admin.css',
            [],
            $this->plugin->version
        );
        wp_enqueue_script('jorgecastro-create-content',
            $this->plugin->plugin_url . 'assets/js/create-content.js',
            ['jquery'],
            $this->plugin->version,
            true
        );
        wp_localize_script('jorgecastro-create-content', 'jorgecastroCreateContent', [
            'site_name' => get_bloginfo('name'),
            'site_url'  => get_site_url(),
        ]);
        add_action('admin_footer', [$this, 'renderCreateContentPopup']);
    }

    /**
     * Render Create Content popup in footer (only called when Create Content page is loaded).
     */
    public function renderCreateContentPopup()
    {
        require_once $this->plugin->plugin_path . 'templates/admin/popup/create-content.tpl.php';
    }

    private function getReturnUrl($key)
    {
        return admin_url() . 'admin.php?page=jorgecastro-setting&m=' . $key;
    }

    private function getWebhookUrl()
    {
        // Use REST API endpoint for webhooks (secure, requires API key authentication)
        return get_site_url() . '/wp-json/jorgecastro/v1/webhook';
    }

    /**
     * Display admin notices based on URL parameters
     * 
     * Note: This method displays user-facing messages from URL parameters (e.g., ?m=success).
     * These are display-only messages and do not perform any security-sensitive operations.
     * Nonce verification is not required here as:
     * 1. This only displays messages, does not modify data
     * 2. User permission check (current_user_can) is enforced
     * 3. Input is validated against allowed values and sanitized
     * 4. Output is properly escaped
     * 
     * @return string HTML notice message
     */
    public function showMessages()
    {
        // Check user permissions - only administrators can see these messages
        if (!current_user_can('manage_options')) {
            return '';
        }

        // Validate and sanitize GET parameters
        // These are display-only messages, not security-sensitive operations
        // but we still validate the input to prevent XSS
        // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only messages from URL parameters. Permission check and input validation are enforced.
        $res = isset($_GET['m']) ? sanitize_text_field(wp_unslash($_GET['m'])) : '';
        $message = '';

        // Only allow specific values to prevent injection
        // This whitelist approach ensures only expected values are processed
        $allowed_messages = ['success', 'failure'];
        if (!in_array($res, $allowed_messages, true)) {
            return '';
        }

        if ($res === 'success') {
            $message = '<div class="notice notice-success"><p><strong>Connection established</strong></p></div>';
        } elseif ($res === 'failure') {
            // phpcs:ignore WordPress.Security.NonceVerification.Recommended -- Display-only error message from URL parameter. Permission check, input validation, and output escaping are enforced.
            $error = isset($_GET['t']) ? sanitize_text_field(wp_unslash($_GET['t'])) : '';
            // Escape the error message for output to prevent XSS
            $message = '<div class="notice notice-error"><p><strong>Error:</strong> ' . esc_html($error) . '</p></div>';
        }
        return $message;
    }

    public function render_page()
    {
        // Default page shows dashboard
        $this->render_dashboard_page();
    }

    public function render_dashboard_page()
    {
        require_once $this->plugin->plugin_path . 'templates/admin/dashboard/entry.tpl.php';
    }

    public function render_settings_page()
    {
        require_once $this->plugin->plugin_path . 'templates/admin/settings/entry.tpl.php';
    }

    public function render_create_content_page()
    {
        // Check if connection is established
        if (!$this->plugin->isConnected()) {
            // Redirect to settings page if not connected
            wp_safe_redirect(admin_url('admin.php?page=jorgecastro-settings'));
            exit;
        }
        
        require_once $this->plugin->plugin_path . 'templates/admin/create-content/entry.tpl.php';
    }

    public function initDashboardPage()
    {
        // Enqueue admin CSS for Dashboard page
        wp_enqueue_style('jorgecastro-admin-css',
            $this->plugin->plugin_url . 'assets/css/admin.css',
            [],
            $this->plugin->version
        );
    }

    public function connectionAjax()
    {
        // Check user permissions
        if (!current_user_can('manage_options')) {
            wp_send_json(['success' => false, 'error' => 'Insufficient permissions']);
            return;
        }

        $nonce = isset($_POST['nonce']) ? sanitize_text_field(wp_unslash($_POST['nonce'])) : '';
        $action = isset($_POST['aj']) ? sanitize_text_field(wp_unslash($_POST['aj'])) : '';
        
        if (!wp_verify_nonce($nonce, 'jorgecastro_ajax_nonce') || empty($action)) {
            wp_send_json(['success' => false, 'error' => 'Invalid request']);
            return;
        }
        
        $ret = ['success' => false];
        
        if ($action === 'connect') {
            $api_key = isset($_POST['api_key']) ? sanitize_text_field(wp_unslash($_POST['api_key'])) : '';
            
            if (empty($api_key)) {
                $ret['error'] = 'API key is required';
                wp_send_json($ret);
                return;
            }
            
            if ($this->plugin->isConnected()) {
                $ret['success'] = true;
                $ret['msg'] = __('Connection established', 'jorgecastro');
                $ret['body'] = __('Your site is connected to jorgeCastro', 'jorgecastro');
            } else {
                $cur_user = wp_get_current_user();

                try {
                    $result = $this->plugin->connect([
                        'user_id' => $cur_user->ID,
                        'user_email' => $cur_user->user_email,
                        'webhook' => $this->getWebhookUrl(),
                        'failure_url' => $this->getReturnUrl('failure'),
                        'api_key' => $api_key
                    ]);

                    if (isset($result['status']) && $result['status'] === 1) {
                        $ret['success'] = true;
                        $ret['msg'] = __('Connection established', 'jorgecastro');
                        $ret['body'] = __('Your site is connected to jorgeCastro', 'jorgecastro');
                    } elseif (isset($result['error'])) {
                        $ret['error'] = $result['error'];
                    } else {
                        $ret['error'] = __('Connection failed. Please check your API key.', 'jorgecastro');
                    }
                } catch (\Exception $e) {
                    $ret['error'] = $e->getMessage();
                }
            }
        } elseif ($action === 'disconnect') {
            if ($this->plugin->isConnected()) {
                $result = $this->plugin->disconnect();
            } else {
                $result = ['status' => 1];
            }

            if (isset($result['status']) && $result['status'] === 1) {
                $ret['success'] = true;
                $ret['msg'] = __('Connection terminated', 'jorgecastro');
                $ret['body'] = __('Your site is not connected to jorgeCastro', 'jorgecastro');
            } elseif (isset($result['error'])) {
                $ret['error'] = $result['error'];
            }
        }

        wp_send_json($ret);
    }

}
