<?php

namespace JorgeCastro\Blog;

defined('WPINC') || exit;

class Handler
{
    private $plugin;

    public function __construct($plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * Create bulk blog posts from data received from SaaS app
     * 
     * @param array $posts Array of blog post data
     * @return array Results with created post IDs and errors
     */
    public function createBulkPosts($posts)
    {
        $results = [
            'success' => 0,
            'failed' => 0,
            'post_ids' => [],
            'errors' => [],
            'image_stats' => [
                'total_images_processed' => 0,
                'content_images' => 0,
                'featured_images' => 0,
                'images_failed' => 0
            ]
        ];

        if (!is_array($posts) || empty($posts)) {
            return $results;
        }

        foreach ($posts as $index => $postData) {
            try {
                // Count images before processing
                $postContentImages = 0;
                if (isset($postData['content'])) {
                    preg_match_all('/<img[^>]+src=["\']([^"\']+)["\'][^>]*>/i', $postData['content'], $matches);
                    $postContentImages = count($matches[0]);
                }
                // Properly check for featured image (handle null, empty string, etc.)
                $hasFeaturedImage = isset($postData['featured_image']) 
                    && $postData['featured_image'] !== null 
                    && $postData['featured_image'] !== '' 
                    && !empty(trim($postData['featured_image']));
                
                $postId = $this->createPost($postData);
                if ($postId && !is_wp_error($postId)) {
                    $results['success']++;
                    $results['post_ids'][] = $postId;
                    
                    // Check if featured image was actually set (from first content image or provided)
                    $actualFeaturedImage = get_post_thumbnail_id($postId);
                    $hasActualFeaturedImage = $actualFeaturedImage > 0;
                    
                    // Count successfully processed images
                    $results['image_stats']['content_images'] += $postContentImages;
                    if ($hasActualFeaturedImage) {
                        $results['image_stats']['featured_images']++;
                    }
                    $results['image_stats']['total_images_processed'] += $postContentImages + ($hasActualFeaturedImage ? 1 : 0);
                } else {
                    $results['failed']++;
                    $results['errors'][] = [
                        'index' => $index,
                        'error' => is_wp_error($postId) ? $postId->get_error_message() : 'Unknown error'
                    ];
                    // Count failed images
                    $results['image_stats']['images_failed'] += $postContentImages + ($hasFeaturedImage ? 1 : 0);
                }
            } catch (\Exception $e) {
                $results['failed']++;
                $results['errors'][] = [
                    'index' => $index,
                    'error' => $e->getMessage()
                ];
            }
        }

        return $results;
    }

    /**
     * Create a single blog post with all metadata
     * 
     * @param array $postData Post data including title, content, categories, tags, featured image, etc.
     * @return int|WP_Error Post ID on success, WP_Error on failure
     */
    private function createPost($postData)
    {
        // Prepare post data
        $postTitle = isset($postData['title']) ? sanitize_text_field($postData['title']) : '';
        $postContent = isset($postData['content']) ? wp_kses_post($postData['content']) : '';
        $postExcerpt = isset($postData['excerpt']) ? sanitize_textarea_field($postData['excerpt']) : '';
        $postDate = isset($postData['date']) ? sanitize_text_field($postData['date']) : current_time('mysql');
        
        // Get post status from request - default to draft if not provided or invalid
        $allowedStatuses = ['publish', 'draft', 'pending', 'private'];
        $postStatus = isset($postData['status']) && in_array($postData['status'], $allowedStatuses) 
            ? $postData['status'] 
            : 'draft';

        if (empty($postTitle) || empty($postContent)) {
            return new \WP_Error('missing_data', 'Title and content are required');
        }

        // Create post with dynamic status
        $postArgs = [
            'post_title' => $postTitle,
            'post_content' => $postContent,
            'post_excerpt' => $postExcerpt,
            'post_status' => $postStatus,
            'post_type' => 'post',
            'post_date' => $postDate,
            'post_author' => get_current_user_id() ?: 1,
        ];

        $postId = wp_insert_post($postArgs, true);

        if (is_wp_error($postId)) {
            return $postId;
        }

        // Set categories
        if (isset($postData['categories']) && is_array($postData['categories'])) {
            $this->setCategories($postId, $postData['categories']);
        }

        // Set tags
        if (isset($postData['tags']) && is_array($postData['tags'])) {
            $this->setTags($postId, $postData['tags']);
        }

        // Process and download images in content (seowriting approach)
        // Properly check for featured image (handle null, empty string, etc.)
        $hasFeaturedImage = isset($postData['featured_image']) 
            && $postData['featured_image'] !== null 
            && $postData['featured_image'] !== '' 
            && !empty(trim($postData['featured_image']));
            
        if (!empty($postContent)) {
            // Process content images - if no featured image provided, use first content image
            $processedContent = $this->processContentImages($postContent, $postId, !$hasFeaturedImage);
            
            // Always update content to ensure WordPress processes it properly
            // Check if images were actually processed (WordPress URLs present)
            $hasWordPressImages = (strpos($processedContent, 'wp-image-') !== false || strpos($processedContent, 'wp-content/uploads') !== false);
            
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: Post ' . $postId . ' - Content changed: ' . ($processedContent !== $postContent ? 'YES' : 'NO') . ', Has WordPress images: ' . ($hasWordPressImages ? 'YES' : 'NO'));
            }
            
            // Update content (always update to ensure processing)
            wp_update_post([
                'ID' => $postId,
                'post_content' => wp_slash($processedContent)
            ]);
        }

        // Set featured image if provided separately
        if ($hasFeaturedImage) {
            $this->setFeaturedImage($postId, $postData['featured_image']);
        }

        // Set post meta
        if (isset($postData['meta']) && is_array($postData['meta'])) {
            $this->setPostMeta($postId, $postData['meta']);
        }

        // Set SEO meta (if Yoast or Rank Math is installed)
        if (isset($postData['seo'])) {
            $this->setSEOMeta($postId, $postData['seo']);
        }

        // Mark post as generated by JorgeCastro SaaS app
        // This helps identify which posts were created via webhook from the SaaS application
        update_post_meta($postId, '_jorgecastro_ai_generated', '1');
        update_post_meta($postId, '_jorgecastro_generated_at', current_time('mysql'));
        
        // Optionally store source information if provided
        if (isset($postData['source_id'])) {
            update_post_meta($postId, '_jorgecastro_source_id', sanitize_text_field($postData['source_id']));
        }

        return $postId;
    }

    /**
     * Set categories for a post
     * 
     * @param int $postId Post ID
     * @param array $categories Array of category names or IDs
     */
    private function setCategories($postId, $categories)
    {
        $categoryIds = [];

        foreach ($categories as $category) {
            if (is_numeric($category)) {
                $categoryIds[] = (int)$category;
            } else {
                // Try to find category by name, create if doesn't exist
                $term = get_term_by('name', sanitize_text_field($category), 'category');
                if ($term) {
                    $categoryIds[] = $term->term_id;
                } else {
                    // Create new category
                    $newTerm = wp_insert_term(sanitize_text_field($category), 'category');
                    if (!is_wp_error($newTerm)) {
                        $categoryIds[] = $newTerm['term_id'];
                    }
                }
            }
        }

        if (!empty($categoryIds)) {
            wp_set_post_categories($postId, $categoryIds);
        }
    }

    /**
     * Set tags for a post
     * 
     * @param int $postId Post ID
     * @param array $tags Array of tag names
     */
    private function setTags($postId, $tags)
    {
        $tagNames = array_map('sanitize_text_field', $tags);
        wp_set_post_tags($postId, $tagNames, false);
    }

    /**
     * Set featured image for a post
     * Uses seowriting best practices
     * 
     * @param int $postId Post ID
     * @param string $imageUrl Image URL or attachment ID
     */
    public function setFeaturedImage($postId, $imageUrl)
    {
        // If it's already an attachment ID
        if (is_numeric($imageUrl)) {
            set_post_thumbnail($postId, (int)$imageUrl);
            return;
        }

        // Extract alt text from URL if possible (for better naming)
        $altText = '';
        $filename = basename(wp_parse_url($imageUrl, PHP_URL_PATH));
        if ($filename) {
            $altText = pathinfo($filename, PATHINFO_FILENAME);
        }

        // Download and attach image using API client (seowriting approach)
        $attachmentId = $this->downloadImage($imageUrl, $postId, $altText);
        if ($attachmentId && !is_wp_error($attachmentId)) {
            set_post_thumbnail($postId, $attachmentId);
        }
    }

    /**
     * Process images in post content - download and replace URLs
     * Based on seowriting plugin best practices
     * 
     * @param string $content Post content with image URLs
     * @param int $postId Post ID
     * @param bool $useFirstAsFeatured Use first image as featured image
     * @return string Processed content with WordPress image tags
     */
    public function processContentImages($content, $postId, $useFirstAsFeatured = false)
    {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        // Extract all images from content using same regex as seowriting
        // Match both regular img tags and figure/img combinations
        if (preg_match_all('/<img[^>]+src=["\']([^"\'>]+)["\'][^>]*>/i', $content, $matches)) {
            // Log found images for debugging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: Found ' . count($matches[1]) . ' images in content');
                foreach ($matches[1] as $idx => $url) {
                    // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                    error_log('Content Generator: Image ' . ($idx + 1) . ': ' . $url);
                }
            }
            
            $api = $this->plugin->getAPIClient();
            $images = []; // Cache for duplicate images
            $featuredSet = false;
            $processedCount = 0;

            foreach ($matches[1] as $i => $imageUrl) {
                // Clean URL
                $imageUrl = trim($imageUrl);
                
                // Skip if already a WordPress URL
                if (strpos($imageUrl, site_url()) !== false || strpos($imageUrl, '/wp-content/') !== false) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log('Content Generator: Skipping WordPress URL: ' . $imageUrl);
                    }
                    continue;
                }
                
                // Skip empty URLs
                if (empty($imageUrl)) {
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log('Content Generator: Skipping empty URL');
                    }
                    continue;
                }

                // Extract alt text (handle both single and double quotes)
                $alt = '';
                if (preg_match('/alt=["\']([^"\']*)["\']/i', $matches[0][$i], $_matches)) {
                    $alt = html_entity_decode($_matches[1], ENT_COMPAT | ENT_HTML401, 'UTF-8');
                }

                $attachmentId = 0;

                // Check if image already downloaded (duplicate check)
                if (isset($images[$imageUrl])) {
                    $attachmentId = $images[$imageUrl];
                } elseif ($file = $api->loadImage($imageUrl, $alt)) {
                    // Log successful file load
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log('Content Generator: Image file loaded successfully: ' . $imageUrl . ' (Size: ' . ($file['size'] ?? 0) . ' bytes)');
                    }
                    
                    // Download and create attachment
                    $id = media_handle_sideload($file, $postId);
                    $api->deleteImage($file);

                    if (is_wp_error($id)) {
                        // Log error but continue
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                            error_log('Content Generator: Image sideload error for ' . $imageUrl . ' - ' . $id->get_error_message());
                        }
                    } else {
                        $attachmentId = $id;
                        $images[$imageUrl] = $id;
                        
                        // Log successful attachment creation
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                            error_log('Content Generator: Image attachment created successfully - ID: ' . $attachmentId . ' for URL: ' . $imageUrl);
                        }

                        // Set alt text if provided
                        if (strlen($alt) > 0) {
                            update_post_meta($attachmentId, '_wp_attachment_image_alt', sanitize_text_field($alt));
                        }

                        // Generate attachment metadata and thumbnails
                        $attach_data = wp_generate_attachment_metadata($attachmentId, get_attached_file($attachmentId));
                        wp_update_attachment_metadata($attachmentId, $attach_data);
                        
                        // Log metadata generation
                        if (defined('WP_DEBUG') && WP_DEBUG) {
                            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                            error_log('Content Generator: Image metadata generated for attachment ID: ' . $attachmentId);
                        }
                    }
                } else {
                    // Log if loadImage failed
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log('Content Generator: Failed to load image ' . $imageUrl . ' - Error: ' . ($api->error ?: 'Unknown error'));
                    }
                }

                // Replace image tag in content
                if ($attachmentId > 0) {
                    if ($useFirstAsFeatured && !$featuredSet) {
                        // Use first image as featured image
                        $thumbnailSet = set_post_thumbnail($postId, $attachmentId);
                        if ($thumbnailSet) {
                            $featuredSet = true;
                            if (defined('WP_DEBUG') && WP_DEBUG) {
                                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                                error_log('Content Generator: First image set as featured - Attachment ID: ' . $attachmentId . ' for Post ID: ' . $postId);
                            }
                            // Remove from content (featured images shouldn't be in content)
                            $content = str_replace($matches[0][$i], '', $content);
                            $processedCount++;
                        } else {
                            // If featured image setting failed, keep image in content
                            if (defined('WP_DEBUG') && WP_DEBUG) {
                                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                                error_log('Content Generator: Failed to set featured image - Attachment ID: ' . $attachmentId . ' for Post ID: ' . $postId);
                            }
                            // Replace with proper WordPress image tag
                            $imageTag = wp_get_attachment_image($attachmentId, 'large', false, [
                                'alt' => $alt,
                                'class' => 'wp-image-' . $attachmentId
                            ]);
                            if ($imageTag) {
                                $content = str_replace($matches[0][$i], $imageTag, $content);
                                $processedCount++;
                            }
                        }
                    } else {
                        // Replace with proper WordPress image tag
                        // Use wp_get_attachment_image for proper WordPress image HTML
                        $imageTag = wp_get_attachment_image($attachmentId, 'large', false, [
                            'alt' => $alt,
                            'class' => 'wp-image-' . $attachmentId
                        ]);
                        if ($imageTag) {
                            $content = str_replace($matches[0][$i], $imageTag, $content);
                            $processedCount++;
                        }
                    }
                } else {
                    // Log if attachment ID is 0 (image not processed)
                    if (defined('WP_DEBUG') && WP_DEBUG) {
                        // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                        error_log('Content Generator: Image not processed - URL: ' . $imageUrl . ', Attachment ID: 0');
                    }
                }
            }
            
            // Log processing results
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: Processed ' . $processedCount . ' images out of ' . count($matches[1]));
            }
        } else {
            // Log if no images found
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: No images found in content');
            }
        }

        return $content;
    }

    /**
     * Download image from URL and create attachment in WordPress media gallery
     * Uses API client loadImage method (seowriting best practice)
     * 
     * @param string $imageUrl Image URL
     * @param int $postId Post ID to attach to
     * @param string $altText Alt text for image
     * @return int|WP_Error Attachment ID or error
     */
    private function downloadImage($imageUrl, $postId, $altText = '')
    {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $api = $this->plugin->getAPIClient();
        
        // Use API client's loadImage method (seowriting approach)
        if ($file = $api->loadImage($imageUrl, $altText)) {
            $attachmentId = media_handle_sideload($file, $postId);
            $api->deleteImage($file);

            if (is_wp_error($attachmentId)) {
                // Log error
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                    error_log('Content Generator: Featured image sideload error - ' . $attachmentId->get_error_message());
                }
                return $attachmentId;
            }

            // Set alt text if provided
            if (strlen($altText) > 0) {
                update_post_meta($attachmentId, '_wp_attachment_image_alt', sanitize_text_field($altText));
            }

            // Generate attachment metadata and thumbnails
            $attach_data = wp_generate_attachment_metadata($attachmentId, get_attached_file($attachmentId));
            wp_update_attachment_metadata($attachmentId, $attach_data);

            return $attachmentId;
        }

        // Log error if loadImage failed
        if (defined('WP_DEBUG') && WP_DEBUG) {
            // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            error_log('Content Generator: Failed to load featured image ' . $imageUrl . ' - ' . ($api->error ?: 'Unknown error'));
        }

        return new \WP_Error('image_download_failed', $api->error ?: 'Failed to download image');
    }

    /**
     * Set post meta data
     * 
     * @param int $postId Post ID
     * @param array $meta Array of meta key-value pairs
     */
    private function setPostMeta($postId, $meta)
    {
        foreach ($meta as $key => $value) {
            $key = sanitize_key($key);
            if (!empty($key)) {
                update_post_meta($postId, $key, sanitize_meta($key, $value, 'post'));
            }
        }
    }

    /**
     * Set SEO meta data (Yoast SEO or Rank Math)
     * Automatically detects installed SEO plugin and assigns meta tags accordingly
     * 
     * @param int $postId Post ID
     * @param array $seoData SEO data (title, description, keywords, etc.)
     */
    private function setSEOMeta($postId, $seoData)
    {
        // Load plugin functions if not already loaded
        if (!function_exists('is_plugin_active')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }

        $title = isset($seoData['title']) ? sanitize_text_field($seoData['title']) : '';
        $description = isset($seoData['description']) ? sanitize_textarea_field($seoData['description']) : '';
        $keywords = isset($seoData['keywords']) ? sanitize_text_field($seoData['keywords']) : '';
        
        // If keywords is comma-separated string, use first as focus keyword
        $focusKeyword = '';
        if (!empty($keywords)) {
            $keywordArray = is_array($seoData['keywords']) ? $seoData['keywords'] : explode(',', $keywords);
            $focusKeyword = trim($keywordArray[0]);
        }

        // Yoast SEO (Free or Premium)
        if (is_plugin_active('wordpress-seo/wp-seo.php') || is_plugin_active('wordpress-seo-premium/wp-seo-premium.php')) {
            if (!empty($title)) {
                update_post_meta($postId, '_yoast_wpseo_title', $title);
            }
            if (!empty($description)) {
                update_post_meta($postId, '_yoast_wpseo_metadesc', $description);
            }
            if (!empty($focusKeyword)) {
                update_post_meta($postId, '_yoast_wpseo_focuskw', $focusKeyword);
            }
            
            // Set additional focus keywords if provided as array
            if (isset($seoData['keywords']) && is_array($seoData['keywords']) && count($seoData['keywords']) > 1) {
                $additionalKeywords = [];
                foreach (array_slice($seoData['keywords'], 1) as $keyword) {
                    $additionalKeywords[] = [
                        'keyword' => sanitize_text_field($keyword),
                        'score' => 0,
                    ];
                }
                if (!empty($additionalKeywords)) {
                    update_post_meta($postId, '_yoast_wpseo_focuskeywords', wp_json_encode($additionalKeywords));
                }
            }
            
            // Log SEO plugin detection
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: Yoast SEO meta tags assigned for Post ID: ' . $postId);
            }
        }

        // Rank Math SEO
        if (is_plugin_active('seo-by-rank-math/rank-math.php')) {
            if (!empty($title)) {
                update_post_meta($postId, 'rank_math_title', $title);
            }
            if (!empty($description)) {
                update_post_meta($postId, 'rank_math_description', $description);
            }
            
            // Set focus keyword (comma-separated string for multiple keywords)
            if (!empty($keywords)) {
                $keywordString = is_array($seoData['keywords']) ? implode(',', array_map('sanitize_text_field', $seoData['keywords'])) : sanitize_text_field($keywords);
                update_post_meta($postId, 'rank_math_focus_keyword', $keywordString);
            } elseif (!empty($focusKeyword)) {
                update_post_meta($postId, 'rank_math_focus_keyword', $focusKeyword);
            }
            
            // Log SEO plugin detection
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: Rank Math SEO meta tags assigned for Post ID: ' . $postId);
            }
        }
        
        // If no SEO plugin is installed, log warning
        if (!is_plugin_active('wordpress-seo/wp-seo.php') 
            && !is_plugin_active('wordpress-seo-premium/wp-seo-premium.php')
            && !is_plugin_active('seo-by-rank-math/rank-math.php')) {
            if (defined('WP_DEBUG') && WP_DEBUG) {
                // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                error_log('Content Generator: No SEO plugin detected (Yoast SEO or Rank Math SEO required) for Post ID: ' . $postId);
            }
        }
    }
}

