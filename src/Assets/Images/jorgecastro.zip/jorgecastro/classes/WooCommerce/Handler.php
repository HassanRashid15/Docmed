<?php

namespace JorgeCastro\WooCommerce;

defined('WPINC') || exit;

class Handler
{
    private $plugin;

    public function __construct($plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * Update bulk WooCommerce products from webhook data
     * 
     * @param array $products Array of product data (can be single product or multiple)
     * @return array Results with updated product IDs and errors
     */
    public function updateBulkProducts($products)
    {
        $results = [
            'success' => 0,
            'failed' => 0,
            'product_ids' => [],
            'errors' => []
        ];

        // Handle single product (convert to array)
        if (!is_array($products)) {
            $products = [$products];
        }

        // If products is wrapped in 'products' key, extract it
        if (isset($products['products']) && is_array($products['products'])) {
            $products = $products['products'];
        }

        // If single product object, wrap in array
        if (isset($products['id']) || isset($products['sku'])) {
            $products = [$products];
        }

        if (empty($products) || !is_array($products)) {
            $results['errors'][] = [
                'error' => 'Invalid products data format'
            ];
            return $results;
        }

        foreach ($products as $index => $productData) {
            try {
                $productId = $this->updateProduct($productData);
                if ($productId && !is_wp_error($productId)) {
                    $results['success']++;
                    $results['product_ids'][] = $productId;
                } else {
                    $results['failed']++;
                    $results['errors'][] = [
                        'index' => $index,
                        'error' => is_wp_error($productId) ? $productId->get_error_message() : 'Unknown error',
                        'data' => isset($productData['id']) ? 'ID: ' . $productData['id'] : (isset($productData['sku']) ? 'SKU: ' . $productData['sku'] : 'Unknown')
                    ];
                }
            } catch (\Exception $e) {
                $results['failed']++;
                $results['errors'][] = [
                    'index' => $index,
                    'error' => $e->getMessage(),
                    'data' => isset($productData['id']) ? 'ID: ' . $productData['id'] : (isset($productData['sku']) ? 'SKU: ' . $productData['sku'] : 'Unknown')
                ];
            }
        }

        return $results;
    }

    /**
     * Update a single WooCommerce product
     * 
     * @param array $productData Product data including id or sku, and fields to update
     * @return int|WP_Error Product ID on success, WP_Error on failure
     */
    private function updateProduct($productData)
    {
        // Find product by ID or SKU
        $product = null;
        
        if (isset($productData['id']) && !empty($productData['id'])) {
            $product = wc_get_product(absint($productData['id']));
        } elseif (isset($productData['sku']) && !empty($productData['sku'])) {
            $product_id = wc_get_product_id_by_sku(sanitize_text_field($productData['sku']));
            if ($product_id) {
                $product = wc_get_product($product_id);
            }
        }

        if (!$product) {
            return new \WP_Error('product_not_found', 'Product not found. Provide either product ID or SKU.');
        }

        $productId = $product->get_id();

        // Update basic product fields
        if (isset($productData['name'])) {
            $product->set_name(sanitize_text_field($productData['name']));
        }

        if (isset($productData['description'])) {
            $product->set_description(wp_kses_post($productData['description']));
        }

        if (isset($productData['short_description'])) {
            $product->set_short_description(sanitize_textarea_field($productData['short_description']));
        }

        if (isset($productData['status'])) {
            $allowed_statuses = ['publish', 'draft', 'pending', 'private'];
            if (in_array($productData['status'], $allowed_statuses)) {
                $product->set_status($productData['status']);
            }
        }

        if (isset($productData['featured'])) {
            $product->set_featured((bool) $productData['featured']);
        }

        if (isset($productData['catalog_visibility'])) {
            $allowed_visibility = ['visible', 'catalog', 'search', 'hidden'];
            if (in_array($productData['catalog_visibility'], $allowed_visibility)) {
                $product->set_catalog_visibility($productData['catalog_visibility']);
            }
        }

        // Update SKU
        if (isset($productData['sku'])) {
            $product->set_sku(sanitize_text_field($productData['sku']));
        }

        // Update pricing
        if (isset($productData['regular_price'])) {
            $product->set_regular_price(sanitize_text_field($productData['regular_price']));
        }

        if (isset($productData['sale_price'])) {
            $product->set_sale_price(sanitize_text_field($productData['sale_price']));
        }

        // Update stock management
        if (isset($productData['manage_stock'])) {
            $product->set_manage_stock((bool) $productData['manage_stock']);
        }

        if (isset($productData['stock_quantity'])) {
            $product->set_stock_quantity(absint($productData['stock_quantity']));
        }

        if (isset($productData['stock_status'])) {
            $allowed_stock_statuses = ['instock', 'outofstock', 'onbackorder'];
            if (in_array($productData['stock_status'], $allowed_stock_statuses)) {
                $product->set_stock_status($productData['stock_status']);
            }
        }

        if (isset($productData['backorders'])) {
            $allowed_backorders = ['no', 'notify', 'yes'];
            if (in_array($productData['backorders'], $allowed_backorders)) {
                $product->set_backorders($productData['backorders']);
            }
        }

        // Update dimensions
        if (isset($productData['weight'])) {
            $product->set_weight(sanitize_text_field($productData['weight']));
        }

        if (isset($productData['length'])) {
            $product->set_length(sanitize_text_field($productData['length']));
        }

        if (isset($productData['width'])) {
            $product->set_width(sanitize_text_field($productData['width']));
        }

        if (isset($productData['height'])) {
            $product->set_height(sanitize_text_field($productData['height']));
        }

        // Save product first to get ID
        $product->save();

        // Update categories
        if (isset($productData['categories']) && is_array($productData['categories'])) {
            $this->setProductCategories($productId, $productData['categories']);
        }

        // Update tags
        if (isset($productData['tags']) && is_array($productData['tags'])) {
            $this->setProductTags($productId, $productData['tags']);
        }

        // Update images
        if (isset($productData['images']) && is_array($productData['images'])) {
            $this->setProductImages($productId, $productData['images']);
        }

        // Update attributes
        if (isset($productData['attributes']) && is_array($productData['attributes'])) {
            $this->setProductAttributes($productId, $product, $productData['attributes']);
        }

        // Update variations for variable products
        if ($product->get_type() === 'variable' && isset($productData['variations']) && is_array($productData['variations'])) {
            $this->updateProductVariations($productId, $productData['variations']);
        }

        // Save again after all updates
        $product->save();

        return $productId;
    }

    /**
     * Set product categories
     * 
     * @param int $productId Product ID
     * @param array $categories Array of category IDs or names
     */
    private function setProductCategories($productId, $categories)
    {
        $categoryIds = [];

        foreach ($categories as $category) {
            if (is_numeric($category)) {
                $categoryIds[] = (int) $category;
            } elseif (is_array($category) && isset($category['id'])) {
                $categoryIds[] = (int) $category['id'];
            } elseif (is_array($category) && isset($category['name'])) {
                // Find or create category by name
                $term = get_term_by('name', sanitize_text_field($category['name']), 'product_cat');
                if ($term) {
                    $categoryIds[] = $term->term_id;
                } else {
                    $newTerm = wp_insert_term(sanitize_text_field($category['name']), 'product_cat');
                    if (!is_wp_error($newTerm)) {
                        $categoryIds[] = $newTerm['term_id'];
                    }
                }
            } elseif (is_string($category)) {
                // Find or create category by name
                $term = get_term_by('name', sanitize_text_field($category), 'product_cat');
                if ($term) {
                    $categoryIds[] = $term->term_id;
                } else {
                    $newTerm = wp_insert_term(sanitize_text_field($category), 'product_cat');
                    if (!is_wp_error($newTerm)) {
                        $categoryIds[] = $newTerm['term_id'];
                    }
                }
            }
        }

        if (!empty($categoryIds)) {
            wp_set_object_terms($productId, $categoryIds, 'product_cat');
        }
    }

    /**
     * Set product tags
     * 
     * @param int $productId Product ID
     * @param array $tags Array of tag names or IDs
     */
    private function setProductTags($productId, $tags)
    {
        $tagNames = [];

        foreach ($tags as $tag) {
            if (is_array($tag) && isset($tag['name'])) {
                $tagNames[] = sanitize_text_field($tag['name']);
            } elseif (is_string($tag)) {
                $tagNames[] = sanitize_text_field($tag);
            }
        }

        if (!empty($tagNames)) {
            wp_set_object_terms($productId, $tagNames, 'product_tag');
        }
    }

    /**
     * Set product images
     * 
     * @param int $productId Product ID
     * @param array $images Array of image URLs or attachment IDs
     */
    private function setProductImages($productId, $images)
    {
        if (empty($images) || !is_array($images)) {
            return;
        }

        $api = $this->plugin->getAPIClient();
        $galleryIds = [];

        foreach ($images as $index => $image) {
            $imageUrl = '';
            $altText = '';

            if (is_array($image)) {
                $imageUrl = isset($image['url']) ? $image['url'] : (isset($image['src']) ? $image['src'] : '');
                $altText = isset($image['alt']) ? $image['alt'] : '';
            } elseif (is_string($image)) {
                $imageUrl = $image;
            } elseif (is_numeric($image)) {
                // Already an attachment ID
                $galleryIds[] = absint($image);
                continue;
            }

            if (empty($imageUrl)) {
                continue;
            }

            // Download and attach image
            $attachmentId = $this->downloadImage($imageUrl, $productId, $altText);
            if ($attachmentId && !is_wp_error($attachmentId)) {
                if ($index === 0) {
                    // First image is featured image
                    set_post_thumbnail($productId, $attachmentId);
                } else {
                    $galleryIds[] = $attachmentId;
                }
            }
        }

        // Set gallery images
        if (!empty($galleryIds)) {
            update_post_meta($productId, '_product_image_gallery', implode(',', $galleryIds));
        }
    }

    /**
     * Set product attributes
     * 
     * @param int $productId Product ID
     * @param \WC_Product $product Product object
     * @param array $attributes Array of attribute data
     */
    private function setProductAttributes($productId, $product, $attributes)
    {
        $productAttributes = [];

        foreach ($attributes as $attribute) {
            if (!is_array($attribute)) {
                continue;
            }

            $attributeName = isset($attribute['name']) ? sanitize_text_field($attribute['name']) : '';
            $attributeOptions = isset($attribute['options']) && is_array($attribute['options']) 
                ? array_map('sanitize_text_field', $attribute['options']) 
                : [];

            if (empty($attributeName) || empty($attributeOptions)) {
                continue;
            }

            // Use WooCommerce's standard helper to get attribute taxonomy name
            // WooCommerce handles the 'pa_' prefix internally - this is WC core standard
            $attribute_slug = sanitize_title($attributeName);
            $taxonomy = wc_attribute_taxonomy_name($attribute_slug);

            // Create attribute using WooCommerce's API if it doesn't exist
            // WooCommerce automatically handles taxonomy registration through its own hooks
            if (!taxonomy_exists($taxonomy)) {
                $attribute_id = wc_create_attribute(array(
                    'name' => $attributeName,
                    'slug' => $attribute_slug,
                    'type' => 'select',
                    'order_by' => 'menu_order',
                    'has_archives' => false,
                ));

                if (is_wp_error($attribute_id)) {
                    continue;
                }

                // Clear attribute cache so WooCommerce can see the new attribute
                delete_transient('wc_attribute_taxonomies');
                
                // Let WooCommerce handle taxonomy registration through its standard mechanism
                // This ensures proper integration with WC core without custom taxonomy calls
                if (function_exists('WC')) {
                    // Trigger WooCommerce to register the new attribute taxonomy
                    WC()->init();
                }
            }

            // Set attribute terms
            $termIds = [];
            foreach ($attributeOptions as $option) {
                $term = get_term_by('name', $option, $taxonomy);
                if (!$term) {
                    $term = wp_insert_term($option, $taxonomy);
                    if (!is_wp_error($term)) {
                        $termIds[] = $term['term_id'];
                    }
                } else {
                    $termIds[] = $term->term_id;
                }
            }

            if (!empty($termIds)) {
                wp_set_object_terms($productId, $termIds, $taxonomy);
            }

            // Add to product attributes
            $productAttributes[$taxonomy] = [
                'name' => $taxonomy,
                'value' => implode(' | ', $attributeOptions),
                'is_visible' => isset($attribute['visible']) ? (bool) $attribute['visible'] : true,
                'is_variation' => isset($attribute['variation']) ? (bool) $attribute['variation'] : false,
                'is_taxonomy' => true,
            ];
        }

        if (!empty($productAttributes)) {
            $product->set_attributes($productAttributes);
            $product->save();
        }
    }

    /**
     * Update product variations
     * 
     * @param int $productId Parent product ID
     * @param array $variations Array of variation data
     */
    private function updateProductVariations($productId, $variations)
    {
        foreach ($variations as $variationData) {
            $variationId = null;

            // Find variation by ID or SKU
            if (isset($variationData['id']) && !empty($variationData['id'])) {
                $variation = wc_get_product(absint($variationData['id']));
                if ($variation && $variation->get_parent_id() == $productId) {
                    $variationId = $variation->get_id();
                }
            } elseif (isset($variationData['sku']) && !empty($variationData['sku'])) {
                $var_id = wc_get_product_id_by_sku(sanitize_text_field($variationData['sku']));
                if ($var_id) {
                    $variation = wc_get_product($var_id);
                    if ($variation && $variation->get_parent_id() == $productId) {
                        $variationId = $variation->get_id();
                    }
                }
            }

            // Create new variation if not found
            if (!$variationId) {
                $variation = new \WC_Product_Variation();
                $variation->set_parent_id($productId);
            } else {
                $variation = wc_get_product($variationId);
            }

            if (!$variation) {
                continue;
            }

            // Update variation fields
            if (isset($variationData['sku'])) {
                $variation->set_sku(sanitize_text_field($variationData['sku']));
            }

            if (isset($variationData['regular_price'])) {
                $variation->set_regular_price(sanitize_text_field($variationData['regular_price']));
            }

            if (isset($variationData['sale_price'])) {
                $variation->set_sale_price(sanitize_text_field($variationData['sale_price']));
            }

            if (isset($variationData['stock_quantity'])) {
                $variation->set_stock_quantity(absint($variationData['stock_quantity']));
            }

            if (isset($variationData['stock_status'])) {
                $allowed_stock_statuses = ['instock', 'outofstock', 'onbackorder'];
                if (in_array($variationData['stock_status'], $allowed_stock_statuses)) {
                    $variation->set_stock_status($variationData['stock_status']);
                }
            }

            // Set variation attributes
            if (isset($variationData['attributes']) && is_array($variationData['attributes'])) {
                $variationAttributes = [];
                foreach ($variationData['attributes'] as $attrName => $attrValue) {
                    $variationAttributes[sanitize_title($attrName)] = sanitize_text_field($attrValue);
                }
                $variation->set_attributes($variationAttributes);
            }

            // Set variation image
            if (isset($variationData['image']) && !empty($variationData['image'])) {
                $imageUrl = is_array($variationData['image']) 
                    ? (isset($variationData['image']['url']) ? $variationData['image']['url'] : (isset($variationData['image']['src']) ? $variationData['image']['src'] : ''))
                    : $variationData['image'];
                
                if (!empty($imageUrl)) {
                    $attachmentId = $this->downloadImage($imageUrl, $productId);
                    if ($attachmentId && !is_wp_error($attachmentId)) {
                        $variation->set_image_id($attachmentId);
                    }
                }
            }

            $variation->save();
        }
    }

    /**
     * Download image from URL and create attachment
     * 
     * @param string $imageUrl Image URL
     * @param int $productId Product ID to attach to
     * @param string $altText Alt text for image
     * @return int|WP_Error Attachment ID or error
     */
    private function downloadImage($imageUrl, $productId, $altText = '')
    {
        require_once(ABSPATH . 'wp-admin/includes/image.php');
        require_once(ABSPATH . 'wp-admin/includes/file.php');
        require_once(ABSPATH . 'wp-admin/includes/media.php');

        $api = $this->plugin->getAPIClient();
        
        if ($file = $api->loadImage($imageUrl, $altText)) {
            $attachmentId = media_handle_sideload($file, $productId);
            $api->deleteImage($file);

            if (is_wp_error($attachmentId)) {
                return $attachmentId;
            }

            // Set alt text if provided
            if (strlen($altText) > 0) {
                update_post_meta($attachmentId, '_wp_attachment_image_alt', sanitize_text_field($altText));
            }

            // Generate attachment metadata
            $attach_data = wp_generate_attachment_metadata($attachmentId, get_attached_file($attachmentId));
            wp_update_attachment_metadata($attachmentId, $attach_data);

            return $attachmentId;
        }

        return new \WP_Error('image_download_failed', $api->error ?: 'Failed to download image');
    }
}

