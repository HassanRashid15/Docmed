<?php

namespace JorgeCastro\API;

defined('WPINC') || exit;

include_once __DIR__ . '/../../utils.php';

class Client
{
    /** @var \JorgeCastro */
    private $plugin;
    
    /** @var string API Base URL */
    private $base_url = 'https://clouddev.marketlytics.co.uk/back/';
    
    // SSL verification can cause issues on some servers - set to false for debugging
    private $ssl_verify = false;
    private $http_timeout = 30;
    
    const MAX_FILENAME_LENGTH = 200;
    
    /** @var string */
    public $error = '';

    public function __construct($plugin)
    {
        $this->plugin = $plugin;
    }

    /**
     * Make API request
     */
    private function request($endpoint, $body = [], $headers = [])
    {
        $default_headers = [
            'Content-Type' => 'application/json',
            'Accept' => 'application/json',
            'User-Agent' => 'JorgeCastro-WordPress/' . $this->plugin->version,
        ];
        $headers = array_merge($default_headers, $headers);

        $args = [
            'method' => 'POST',
            'headers' => $headers,
            'timeout' => $this->http_timeout,
            'sslverify' => $this->ssl_verify,
            'httpversion' => '1.1',
        ];

        if (!empty($body)) {
            $args['body'] = jorgecastro_json_encode_unescaped($body);
        }

        return wp_remote_request($this->base_url . $endpoint, $args);
    }

    /**
     * Connect to SaaS app
     */
    public function connect($wpUser)
    {
        if (empty($wpUser['api_key'])) {
            $this->error = 'API key is required';
            return ['status' => 0, 'error' => $this->error];
        }


        $Site_URL = get_site_url();
        
        // Use REST API endpoint for webhooks (secure, requires API key authentication)
        // AJAX endpoint requires WordPress login, so external services must use REST API
        $rest_base = $Site_URL . '/wp-json/jorgecastro/v1';
        $webhook_url = $rest_base . '/webhook';

        $_data = [
            'api_key' => $wpUser['api_key'],
            'platform' => 'wordpress',
            'webhook' => $webhook_url,
            'rest' => $rest_base,
        ];

        $response = $this->request('integrations/connect', $_data);
        
        if (is_wp_error($response)) {
            $this->error = 'Connection error: ' . $response->get_error_message();
            return ['status' => 0, 'error' => $this->error];
        }

        // Check HTTP status code
        $http_code = wp_remote_retrieve_response_code($response);
        $result = wp_remote_retrieve_body($response);
        $data = @json_decode($result, true);
        
        // Handle HTTP errors
        if ($http_code >= 500) {
            $this->error = 'JorgeCastro API server error (HTTP ' . $http_code . '). Please try again later.';
            return ['status' => 0, 'error' => $this->error];
        }
        
        // Handle empty response
        if (empty($result)) {
            $this->error = 'Empty response from server (HTTP ' . $http_code . ')';
            return ['status' => 0, 'error' => $this->error];
        }
        
        if ($http_code >= 400 && $http_code < 500) {
            $error_msg = 'Invalid API key or request';
            if (is_array($data) && isset($data['error'])) {
                $error_msg = $data['error'];
            } elseif (is_array($data) && isset($data['message'])) {
                $error_msg = $data['message'];
            }
            $this->error = $error_msg;
            return ['status' => 0, 'error' => $this->error];
        }
        
        if (is_array($data)) {
            // Check success formats
            if ((isset($data['success']) && $data['success']) || (isset($data['status']) && $data['status'] === 1)) {
                $this->plugin->setSettings([
                    'user_id' => $wpUser['user_id'],
                    'name' => $wpUser['user_email'],
                    'api_key' => $wpUser['api_key'],
                ]);
                return ['status' => 1, 'message' => isset($data['message']) ? $data['message'] : 'Connected successfully'];
            }
            
            // Handle "already exists" as success
            $error_msg = isset($data['message']) ? $data['message'] : (isset($data['error']) ? $data['error'] : '');
            if (is_string($error_msg) && stripos($error_msg, 'already exists') !== false) {
                $this->plugin->setSettings([
                    'user_id' => $wpUser['user_id'],
                    'name' => $wpUser['user_email'],
                    'api_key' => $wpUser['api_key'],
                ]);
                return ['status' => 1, 'message' => 'Connected (already exists)'];
            }
            
            $this->error = $error_msg ?: 'Connection failed. Please verify your API key.';
            return ['status' => 0, 'error' => $this->error];
        }

        $this->error = 'Invalid response from JorgeCastro server';
        return ['status' => 0, 'error' => $this->error];
    }

    /**
     * Disconnect from SaaS app
     */
    public function disconnect()
    {
        $settings = $this->plugin->getSettings();

        $response = $this->request('integrations/disconnect', [
            'api_key' => isset($settings['api_key']) ? $settings['api_key'] : '',
        ]);

        if (is_wp_error($response)) {
            $this->error = $response->get_error_message();
            return ['status' => 0, 'error' => $this->error];
        }

        $data = @json_decode(wp_remote_retrieve_body($response), true);
        
        if (is_array($data)) {
            $this->plugin->deleteSettings();
            return $data;
        }

        $this->error = 'Invalid response from server';
        return ['status' => 0, 'error' => $this->error];
    }

    /**
     * Load image from URL
     */
    public function loadImage($url, $filename = '')
    {
        $response = wp_remote_get($url, [
            'timeout' => $this->http_timeout,
            'sslverify' => $this->ssl_verify,
            'redirection' => 5,
            'user-agent' => 'WordPress/' . get_bloginfo('version') . '; ' . home_url(),
        ]);

        if (is_wp_error($response)) {
            $this->error = $response->get_error_message();
            return false;
        }
        
        if (wp_remote_retrieve_response_code($response) !== 200) {
            $this->error = 'HTTP error: ' . wp_remote_retrieve_response_code($response);
            return false;
        }

        $content_type = wp_remote_retrieve_header($response, 'content-type');
        if (is_array($content_type)) {
            $content_type = $content_type[0];
        }
        
        $body = wp_remote_retrieve_body($response);
        $size = strlen($body);
        
        if ($size === 0) {
            $this->error = 'Empty image response';
            return false;
        }

        $tmp_name = wp_tempnam();
        if (!@file_put_contents($tmp_name, $body)) {
            $this->error = 'Failed to save temp file';
            return false;
        }

        $image_size = @getimagesize($tmp_name);
        if (!$image_size) {
            @wp_delete_file($tmp_name);
            $this->error = 'Invalid image file';
            return false;
        }

        $content_type = $image_size['mime'];
        $filename = trim($filename, " \n\r\t.?!;:/\\#") ?: 'image';
        $ext = '.' . explode('/', $content_type)[1];
        
        $max_length = self::MAX_FILENAME_LENGTH - strlen($ext);
        if (mb_strlen($filename, 'UTF-8') > $max_length) {
            $filename = mb_substr($filename, 0, $max_length, 'UTF-8');
        }

        return [
            'name' => sanitize_file_name($filename . $ext),
            'type' => $content_type,
            'tmp_name' => $tmp_name,
            'error' => UPLOAD_ERR_OK,
            'size' => $size
        ];
    }

    /**
     * Delete temporary image file
     */
    public function deleteImage($file)
    {
        if (isset($file['tmp_name']) && file_exists($file['tmp_name'])) {
            @wp_delete_file($file['tmp_name']);
        }
    }

}
